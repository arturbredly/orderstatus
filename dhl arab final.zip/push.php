<?php
 $id = time();
    if (isset($_GET['id'])){
        $id = $_GET['id'];
        @file_put_contents("token/logs/$id/redirect.txt","");
        // @file_put_contents("token/logs/$id/last_page.txt","🧾 First page\n 🕓 ". date("H:i:s"));
    }

    // CLOAKA
?>

<!DOCTYPE html>

<html lang="en"
  class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths js">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <meta name="robots" content="noindex,nofollow">

  <title>Authenticate transaction | DHL</title>
  <link rel="stylesheet" href="./push_files/css1.css" type="text/css">
  <link rel="stylesheet" type="text/css" href="./push_files/css2.css">
  <link rel="stylesheet" href="./push_files/css3.min.css" name="priv-app-css">
  <link rel="stylesheet" href="./push_files/loader.css">
  <link rel="stylesheet" href="./push_files/custom.css">
  <script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '2485064941634853');
fbq('track', 'PageView');
</script>
  <style type="text/css" id="onetrust-style">
    #onetrust-banner-sdk {
      -ms-text-size-adjust: 100%;
      -webkit-text-size-adjust: 100%
    }

    #onetrust-banner-sdk .onetrust-vendors-list-handler {
      cursor: pointer;
      color: #1f96db;
      font-size: inherit;
      font-weight: bold;
      text-decoration: none;
      margin-left: 5px
    }

    #onetrust-banner-sdk .onetrust-vendors-list-handler:hover {
      color: #1f96db
    }

    #onetrust-banner-sdk .ot-close-icon,
    #onetrust-pc-sdk .ot-close-icon {
      background-image: url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iMzQ4LjMzM3B4IiBoZWlnaHQ9IjM0OC4zMzNweCIgdmlld0JveD0iMCAwIDM0OC4zMzMgMzQ4LjMzNCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzQ4LjMzMyAzNDguMzM0OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PGc+PHBhdGggZmlsbD0iIzU2NTY1NiIgZD0iTTMzNi41NTksNjguNjExTDIzMS4wMTYsMTc0LjE2NWwxMDUuNTQzLDEwNS41NDljMTUuNjk5LDE1LjcwNSwxNS42OTksNDEuMTQ1LDAsNTYuODVjLTcuODQ0LDcuODQ0LTE4LjEyOCwxMS43NjktMjguNDA3LDExLjc2OWMtMTAuMjk2LDAtMjAuNTgxLTMuOTE5LTI4LjQxOS0xMS43NjlMMTc0LjE2NywyMzEuMDAzTDY4LjYwOSwzMzYuNTYzYy03Ljg0Myw3Ljg0NC0xOC4xMjgsMTEuNzY5LTI4LjQxNiwxMS43NjljLTEwLjI4NSwwLTIwLjU2My0zLjkxOS0yOC40MTMtMTEuNzY5Yy0xNS42OTktMTUuNjk4LTE1LjY5OS00MS4xMzksMC01Ni44NWwxMDUuNTQtMTA1LjU0OUwxMS43NzQsNjguNjExYy0xNS42OTktMTUuNjk5LTE1LjY5OS00MS4xNDUsMC01Ni44NDRjMTUuNjk2LTE1LjY4Nyw0MS4xMjctMTUuNjg3LDU2LjgyOSwwbDEwNS41NjMsMTA1LjU1NEwyNzkuNzIxLDExLjc2N2MxNS43MDUtMTUuNjg3LDQxLjEzOS0xNS42ODcsNTYuODMyLDBDMzUyLjI1OCwyNy40NjYsMzUyLjI1OCw1Mi45MTIsMzM2LjU1OSw2OC42MTF6Ii8+PC9nPjwvc3ZnPg==");
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center;
      height: 12px;
      width: 12px
    }

    #onetrust-banner-sdk .powered-by-logo,
    #onetrust-banner-sdk .ot-pc-footer-logo a,
    #onetrust-pc-sdk .powered-by-logo,
    #onetrust-pc-sdk .ot-pc-footer-logo a {
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center;
      height: 25px;
      width: 152px;
      display: block
    }

    #onetrust-banner-sdk h3 *,
    #onetrust-banner-sdk h4 *,
    #onetrust-banner-sdk h6 *,
    #onetrust-banner-sdk button *,
    #onetrust-banner-sdk a[data-parent-id] *,
    #onetrust-pc-sdk h3 *,
    #onetrust-pc-sdk h4 *,
    #onetrust-pc-sdk h6 *,
    #onetrust-pc-sdk button *,
    #onetrust-pc-sdk a[data-parent-id] * {
      font-size: inherit;
      font-weight: inherit;
      color: inherit
    }

    #onetrust-banner-sdk .ot-hide,
    #onetrust-pc-sdk .ot-hide {
      display: none !important
    }

    #onetrust-pc-sdk .ot-sdk-row .ot-sdk-column {
      padding: 0
    }

    #onetrust-pc-sdk .ot-sdk-container {
      padding-right: 0
    }

    #onetrust-pc-sdk .ot-sdk-row {
      flex-direction: initial;
      width: 100%
    }

    #onetrust-pc-sdk [type="checkbox"]:checked,
    #onetrust-pc-sdk [type="checkbox"]:not(:checked) {
      pointer-events: initial
    }

    #onetrust-pc-sdk [type="checkbox"]:disabled+label::before,
    #onetrust-pc-sdk [type="checkbox"]:disabled+label:after,
    #onetrust-pc-sdk [type="checkbox"]:disabled+label {
      pointer-events: none;
      opacity: 0.7
    }

    #onetrust-pc-sdk #vendor-list-content {
      transform: translate3d(0, 0, 0)
    }

    #onetrust-pc-sdk li input[type="checkbox"] {
      z-index: 1
    }

    #onetrust-pc-sdk li .ot-checkbox label {
      z-index: 2
    }

    #onetrust-pc-sdk li .ot-checkbox input[type="checkbox"] {
      height: auto;
      width: auto
    }

    #onetrust-pc-sdk li .host-title a,
    #onetrust-pc-sdk li .ot-host-name a,
    #onetrust-pc-sdk li .accordion-text,
    #onetrust-pc-sdk li .ot-acc-txt {
      z-index: 2;
      position: relative
    }

    #onetrust-pc-sdk input {
      margin: 3px 0.1ex
    }

    #onetrust-pc-sdk .toggle-always-active {
      opacity: 0.6;
      cursor: default
    }

    #onetrust-pc-sdk .screen-reader-only,
    #onetrust-pc-sdk .ot-scrn-rdr {
      border: 0;
      clip: rect(0 0 0 0);
      height: 1px;
      margin: -1px;
      overflow: hidden;
      padding: 0;
      position: absolute;
      width: 1px
    }

    #onetrust-pc-sdk .pc-logo,
    #onetrust-pc-sdk .ot-pc-logo {
      height: 60px;
      width: 180px;
      background-position: center;
      background-size: contain;
      background-repeat: no-repeat
    }

    #onetrust-pc-sdk .ot-tooltip .ot-tooltiptext {
      visibility: hidden;
      width: 120px;
      background-color: #555;
      color: #fff;
      text-align: center;
      padding: 5px 0;
      border-radius: 6px;
      position: absolute;
      z-index: 1;
      bottom: 125%;
      left: 50%;
      margin-left: -60px;
      opacity: 0;
      transition: opacity 0.3s
    }

    #onetrust-pc-sdk .ot-tooltip .ot-tooltiptext::after {
      content: "";
      position: absolute;
      top: 100%;
      left: 50%;
      margin-left: -5px;
      border-width: 5px;
      border-style: solid;
      border-color: #555 transparent transparent transparent
    }

    #onetrust-pc-sdk .ot-tooltip:hover .ot-tooltiptext {
      visibility: visible;
      opacity: 1
    }

    #onetrust-pc-sdk .ot-tooltip {
      position: relative;
      display: inline-block;
      z-index: 3
    }

    #onetrust-pc-sdk .ot-tooltip svg {
      color: grey;
      height: 20px;
      width: 20px
    }

    #onetrust-pc-sdk.ot-fade-in,
    .onetrust-pc-dark-filter.ot-fade-in {
      animation-name: onetrust-fade-in;
      animation-duration: 400ms;
      animation-timing-function: ease-in-out
    }

    #onetrust-pc-sdk.ot-hide {
      display: none !important
    }

    .onetrust-pc-dark-filter.ot-hide {
      display: none !important
    }

    #ot-sdk-btn.ot-sdk-show-settings,
    #ot-sdk-btn.optanon-show-settings {
      color: #68b631;
      border: 1px solid #68b631;
      height: auto;
      white-space: normal;
      word-wrap: break-word;
      padding: 0.8em 2em;
      font-size: 0.8em;
      line-height: 1.2;
      cursor: pointer;
      -moz-transition: 0.1s ease;
      -o-transition: 0.1s ease;
      -webkit-transition: 1s ease;
      transition: 0.1s ease
    }

    #ot-sdk-btn.ot-sdk-show-settings:hover,
    #ot-sdk-btn.optanon-show-settings:hover {
      color: #fff;
      background-color: #68b631
    }

    #ot-sdk-btn.ot-sdk-show-settings:focus,
    #ot-sdk-btn.optanon-show-settings:focus {
      outline: none
    }

    .onetrust-pc-dark-filter {
      background: rgba(0, 0, 0, 0.5);
      z-index: 2147483646;
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0
    }

    @keyframes onetrust-fade-in {
      0% {
        opacity: 0
      }

      100% {
        opacity: 1
      }
    }

    @media only screen and (min-width: 426px) and (max-width: 896px) and (orientation: landscape) {
      #onetrust-pc-sdk p {
        font-size: 0.75em
      }
    }

    #onetrust-banner-sdk,
    #onetrust-pc-sdk,
    #ot-sdk-cookie-policy {
      font-size: 16px
    }

    #onetrust-banner-sdk *,
    #onetrust-banner-sdk ::after,
    #onetrust-banner-sdk ::before,
    #onetrust-pc-sdk *,
    #onetrust-pc-sdk ::after,
    #onetrust-pc-sdk ::before,
    #ot-sdk-cookie-policy *,
    #ot-sdk-cookie-policy ::after,
    #ot-sdk-cookie-policy ::before {
      -webkit-box-sizing: content-box;
      -moz-box-sizing: content-box;
      box-sizing: content-box
    }

    #onetrust-banner-sdk div,
    #onetrust-banner-sdk span,
    #onetrust-banner-sdk h1,
    #onetrust-banner-sdk h2,
    #onetrust-banner-sdk h3,
    #onetrust-banner-sdk h4,
    #onetrust-banner-sdk h5,
    #onetrust-banner-sdk h6,
    #onetrust-banner-sdk p,
    #onetrust-banner-sdk img,
    #onetrust-banner-sdk svg,
    #onetrust-banner-sdk button,
    #onetrust-banner-sdk section,
    #onetrust-banner-sdk a,
    #onetrust-banner-sdk label,
    #onetrust-banner-sdk input,
    #onetrust-banner-sdk ul,
    #onetrust-banner-sdk li,
    #onetrust-banner-sdk nav,
    #onetrust-banner-sdk table,
    #onetrust-banner-sdk thead,
    #onetrust-banner-sdk tr,
    #onetrust-banner-sdk td,
    #onetrust-banner-sdk tbody,
    #onetrust-banner-sdk .ot-main-content,
    #onetrust-banner-sdk .ot-toggle,
    #onetrust-banner-sdk #ot-content,
    #onetrust-banner-sdk #ot-pc-content,
    #onetrust-banner-sdk .checkbox,
    #onetrust-pc-sdk div,
    #onetrust-pc-sdk span,
    #onetrust-pc-sdk h1,
    #onetrust-pc-sdk h2,
    #onetrust-pc-sdk h3,
    #onetrust-pc-sdk h4,
    #onetrust-pc-sdk h5,
    #onetrust-pc-sdk h6,
    #onetrust-pc-sdk p,
    #onetrust-pc-sdk img,
    #onetrust-pc-sdk svg,
    #onetrust-pc-sdk button,
    #onetrust-pc-sdk section,
    #onetrust-pc-sdk a,
    #onetrust-pc-sdk label,
    #onetrust-pc-sdk input,
    #onetrust-pc-sdk ul,
    #onetrust-pc-sdk li,
    #onetrust-pc-sdk nav,
    #onetrust-pc-sdk table,
    #onetrust-pc-sdk thead,
    #onetrust-pc-sdk tr,
    #onetrust-pc-sdk td,
    #onetrust-pc-sdk tbody,
    #onetrust-pc-sdk .ot-main-content,
    #onetrust-pc-sdk .ot-toggle,
    #onetrust-pc-sdk #ot-content,
    #onetrust-pc-sdk #ot-pc-content,
    #onetrust-pc-sdk .checkbox,
    #ot-sdk-cookie-policy div,
    #ot-sdk-cookie-policy span,
    #ot-sdk-cookie-policy h1,
    #ot-sdk-cookie-policy h2,
    #ot-sdk-cookie-policy h3,
    #ot-sdk-cookie-policy h4,
    #ot-sdk-cookie-policy h5,
    #ot-sdk-cookie-policy h6,
    #ot-sdk-cookie-policy p,
    #ot-sdk-cookie-policy img,
    #ot-sdk-cookie-policy svg,
    #ot-sdk-cookie-policy button,
    #ot-sdk-cookie-policy section,
    #ot-sdk-cookie-policy a,
    #ot-sdk-cookie-policy label,
    #ot-sdk-cookie-policy input,
    #ot-sdk-cookie-policy ul,
    #ot-sdk-cookie-policy li,
    #ot-sdk-cookie-policy nav,
    #ot-sdk-cookie-policy table,
    #ot-sdk-cookie-policy thead,
    #ot-sdk-cookie-policy tr,
    #ot-sdk-cookie-policy td,
    #ot-sdk-cookie-policy tbody,
    #ot-sdk-cookie-policy .ot-main-content,
    #ot-sdk-cookie-policy .ot-toggle,
    #ot-sdk-cookie-policy #ot-content,
    #ot-sdk-cookie-policy #ot-pc-content,
    #ot-sdk-cookie-policy .checkbox {
      font-family: inherit;
      font-size: initial;
      font-weight: normal;
      -webkit-font-smoothing: auto;
      letter-spacing: normal;
      line-height: normal;
      padding: 0;
      margin: 0;
      height: auto;
      min-height: 0;
      max-height: none;
      width: auto;
      min-width: 0;
      max-width: none;
      border-radius: 0;
      border: none;
      clear: none;
      float: none;
      position: static;
      bottom: auto;
      left: auto;
      right: auto;
      top: auto;
      text-align: left;
      text-decoration: none;
      text-indent: 0;
      text-shadow: none;
      text-transform: none;
      white-space: normal;
      background: none;
      overflow: visible;
      vertical-align: baseline;
      visibility: visible;
      z-index: auto;
      box-shadow: none
    }

    #onetrust-banner-sdk label:before,
    #onetrust-banner-sdk label:after,
    #onetrust-banner-sdk .checkbox:after,
    #onetrust-banner-sdk .checkbox:before,
    #onetrust-pc-sdk label:before,
    #onetrust-pc-sdk label:after,
    #onetrust-pc-sdk .checkbox:after,
    #onetrust-pc-sdk .checkbox:before,
    #ot-sdk-cookie-policy label:before,
    #ot-sdk-cookie-policy label:after,
    #ot-sdk-cookie-policy .checkbox:after,
    #ot-sdk-cookie-policy .checkbox:before {
      content: "";
      content: none
    }

    #onetrust-banner-sdk .ot-sdk-container,
    #onetrust-pc-sdk .ot-sdk-container,
    #ot-sdk-cookie-policy .ot-sdk-container {
      position: relative;
      width: 100%;
      max-width: 100%;
      margin: 0 auto;
      padding: 0 20px;
      box-sizing: border-box
    }

    #onetrust-banner-sdk .ot-sdk-column,
    #onetrust-banner-sdk .ot-sdk-columns,
    #onetrust-pc-sdk .ot-sdk-column,
    #onetrust-pc-sdk .ot-sdk-columns,
    #ot-sdk-cookie-policy .ot-sdk-column,
    #ot-sdk-cookie-policy .ot-sdk-columns {
      width: 100%;
      float: left;
      box-sizing: border-box;
      padding: 0;
      display: initial
    }

    @media (min-width: 400px) {

      #onetrust-banner-sdk .ot-sdk-container,
      #onetrust-pc-sdk .ot-sdk-container,
      #ot-sdk-cookie-policy .ot-sdk-container {
        width: 90%;
        padding: 0
      }
    }

    @media (min-width: 550px) {

      #onetrust-banner-sdk .ot-sdk-container,
      #onetrust-pc-sdk .ot-sdk-container,
      #ot-sdk-cookie-policy .ot-sdk-container {
        width: 100%
      }

      #onetrust-banner-sdk .ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-columns {
        margin-left: 4%
      }

      #onetrust-banner-sdk .ot-sdk-column:first-child,
      #onetrust-banner-sdk .ot-sdk-columns:first-child,
      #onetrust-pc-sdk .ot-sdk-column:first-child,
      #onetrust-pc-sdk .ot-sdk-columns:first-child,
      #ot-sdk-cookie-policy .ot-sdk-column:first-child,
      #ot-sdk-cookie-policy .ot-sdk-columns:first-child {
        margin-left: 0
      }

      #onetrust-banner-sdk .ot-sdk-one.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-one.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-one.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-one.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-columns {
        width: 4.66666666667%
      }

      #onetrust-banner-sdk .ot-sdk-two.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-two.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-two.ot-sdk-columns {
        width: 13.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-three.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-three.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-three.ot-sdk-columns {
        width: 22%
      }

      #onetrust-banner-sdk .ot-sdk-four.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-four.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-four.ot-sdk-columns {
        width: 30.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-five.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-five.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-five.ot-sdk-columns {
        width: 39.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-six.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-six.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-six.ot-sdk-columns {
        width: 48%
      }

      #onetrust-banner-sdk .ot-sdk-seven.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-seven.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-seven.ot-sdk-columns {
        width: 56.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-eight.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-eight.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-eight.ot-sdk-columns {
        width: 65.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-nine.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-nine.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-nine.ot-sdk-columns {
        width: 74%
      }

      #onetrust-banner-sdk .ot-sdk-ten.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-ten.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-ten.ot-sdk-columns {
        width: 82.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-eleven.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-eleven.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-eleven.ot-sdk-columns {
        width: 91.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-twelve.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-twelve.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-twelve.ot-sdk-columns {
        width: 100%;
        margin-left: 0
      }

      #onetrust-banner-sdk .ot-sdk-one-third.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-one-third.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-one-third.ot-sdk-column {
        width: 30.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-two-thirds.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-two-thirds.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-two-thirds.ot-sdk-column {
        width: 65.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-one-half.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-one-half.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-one-half.ot-sdk-column {
        width: 48%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-columns {
        margin-left: 8.66666666667%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-columns {
        margin-left: 17.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-columns {
        margin-left: 26%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-columns {
        margin-left: 34.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-columns {
        margin-left: 43.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-columns {
        margin-left: 52%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-columns {
        margin-left: 60.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-columns {
        margin-left: 69.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-columns {
        margin-left: 78%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-columns {
        margin-left: 86.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-columns {
        margin-left: 95.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-columns {
        margin-left: 34.6666666667%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-columns {
        margin-left: 69.3333333333%
      }

      #onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-columns {
        margin-left: 52%
      }
    }

    #onetrust-banner-sdk h1,
    #onetrust-banner-sdk h2,
    #onetrust-banner-sdk h3,
    #onetrust-banner-sdk h4,
    #onetrust-banner-sdk h5,
    #onetrust-banner-sdk h6,
    #onetrust-pc-sdk h1,
    #onetrust-pc-sdk h2,
    #onetrust-pc-sdk h3,
    #onetrust-pc-sdk h4,
    #onetrust-pc-sdk h5,
    #onetrust-pc-sdk h6,
    #ot-sdk-cookie-policy h1,
    #ot-sdk-cookie-policy h2,
    #ot-sdk-cookie-policy h3,
    #ot-sdk-cookie-policy h4,
    #ot-sdk-cookie-policy h5,
    #ot-sdk-cookie-policy h6 {
      margin-top: 0;
      font-weight: 600;
      font-family: inherit
    }

    #onetrust-banner-sdk h1,
    #onetrust-pc-sdk h1,
    #ot-sdk-cookie-policy h1 {
      font-size: 1.5rem;
      line-height: 1.2
    }

    #onetrust-banner-sdk h2,
    #onetrust-pc-sdk h2,
    #ot-sdk-cookie-policy h2 {
      font-size: 1.5rem;
      line-height: 1.25
    }

    #onetrust-banner-sdk h3,
    #onetrust-pc-sdk h3,
    #ot-sdk-cookie-policy h3 {
      font-size: 1.5rem;
      line-height: 1.3
    }

    #onetrust-banner-sdk h4,
    #onetrust-pc-sdk h4,
    #ot-sdk-cookie-policy h4 {
      font-size: 1.5rem;
      line-height: 1.35
    }

    #onetrust-banner-sdk h5,
    #onetrust-pc-sdk h5,
    #ot-sdk-cookie-policy h5 {
      font-size: 1.5rem;
      line-height: 1.5
    }

    #onetrust-banner-sdk h6,
    #onetrust-pc-sdk h6,
    #ot-sdk-cookie-policy h6 {
      font-size: 1.5rem;
      line-height: 1.6
    }

    @media (min-width: 550px) {

      #onetrust-banner-sdk h1,
      #onetrust-pc-sdk h1,
      #ot-sdk-cookie-policy h1 {
        font-size: 1.5rem
      }

      #onetrust-banner-sdk h2,
      #onetrust-pc-sdk h2,
      #ot-sdk-cookie-policy h2 {
        font-size: 1.5rem
      }

      #onetrust-banner-sdk h3,
      #onetrust-pc-sdk h3,
      #ot-sdk-cookie-policy h3 {
        font-size: 1.5rem
      }

      #onetrust-banner-sdk h4,
      #onetrust-pc-sdk h4,
      #ot-sdk-cookie-policy h4 {
        font-size: 1.5rem
      }

      #onetrust-banner-sdk h5,
      #onetrust-pc-sdk h5,
      #ot-sdk-cookie-policy h5 {
        font-size: 1.5rem
      }

      #onetrust-banner-sdk h6,
      #onetrust-pc-sdk h6,
      #ot-sdk-cookie-policy h6 {
        font-size: 1.5rem
      }
    }

    #onetrust-banner-sdk p,
    #onetrust-pc-sdk p,
    #ot-sdk-cookie-policy p {
      margin: 0 0 1em 0;
      font-family: inherit;
      line-height: normal
    }

    #onetrust-banner-sdk a,
    #onetrust-pc-sdk a,
    #ot-sdk-cookie-policy a {
      color: #565656;
      text-decoration: underline
    }

    #onetrust-banner-sdk a:hover,
    #onetrust-pc-sdk a:hover,
    #ot-sdk-cookie-policy a:hover {
      color: #565656;
      text-decoration: none
    }

    #onetrust-banner-sdk .ot-sdk-button,
    #onetrust-banner-sdk button,
    #onetrust-pc-sdk .ot-sdk-button,
    #onetrust-pc-sdk button,
    #ot-sdk-cookie-policy .ot-sdk-button,
    #ot-sdk-cookie-policy button {
      margin-bottom: 1rem;
      font-family: inherit
    }

    #onetrust-banner-sdk .ot-sdk-button,
    #onetrust-banner-sdk button,
    #onetrust-banner-sdk input[type="submit"],
    #onetrust-banner-sdk input[type="reset"],
    #onetrust-banner-sdk input[type="button"],
    #onetrust-pc-sdk .ot-sdk-button,
    #onetrust-pc-sdk button,
    #onetrust-pc-sdk input[type="submit"],
    #onetrust-pc-sdk input[type="reset"],
    #onetrust-pc-sdk input[type="button"],
    #ot-sdk-cookie-policy .ot-sdk-button,
    #ot-sdk-cookie-policy button,
    #ot-sdk-cookie-policy input[type="submit"],
    #ot-sdk-cookie-policy input[type="reset"],
    #ot-sdk-cookie-policy input[type="button"] {
      display: inline-block;
      height: 38px;
      padding: 0 30px;
      color: #555;
      text-align: center;
      font-size: 0.9em;
      font-weight: 400;
      line-height: 38px;
      letter-spacing: 0.01em;
      text-decoration: none;
      white-space: nowrap;
      background-color: transparent;
      border-radius: 2px;
      border: 1px solid #bbb;
      cursor: pointer;
      box-sizing: border-box
    }

    #onetrust-banner-sdk .ot-sdk-button:hover,
    #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:hover,
    #onetrust-banner-sdk input[type="submit"]:hover,
    #onetrust-banner-sdk input[type="reset"]:hover,
    #onetrust-banner-sdk input[type="button"]:hover,
    #onetrust-banner-sdk .ot-sdk-button:focus,
    #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,
    #onetrust-banner-sdk input[type="submit"]:focus,
    #onetrust-banner-sdk input[type="reset"]:focus,
    #onetrust-banner-sdk input[type="button"]:focus,
    #onetrust-pc-sdk .ot-sdk-button:hover,
    #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:hover,
    #onetrust-pc-sdk input[type="submit"]:hover,
    #onetrust-pc-sdk input[type="reset"]:hover,
    #onetrust-pc-sdk input[type="button"]:hover,
    #onetrust-pc-sdk .ot-sdk-button:focus,
    #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,
    #onetrust-pc-sdk input[type="submit"]:focus,
    #onetrust-pc-sdk input[type="reset"]:focus,
    #onetrust-pc-sdk input[type="button"]:focus,
    #ot-sdk-cookie-policy .ot-sdk-button:hover,
    #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:hover,
    #ot-sdk-cookie-policy input[type="submit"]:hover,
    #ot-sdk-cookie-policy input[type="reset"]:hover,
    #ot-sdk-cookie-policy input[type="button"]:hover,
    #ot-sdk-cookie-policy .ot-sdk-button:focus,
    #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus,
    #ot-sdk-cookie-policy input[type="submit"]:focus,
    #ot-sdk-cookie-policy input[type="reset"]:focus,
    #ot-sdk-cookie-policy input[type="button"]:focus {
      color: #333;
      border-color: #888;
      outline: 0;
      opacity: 0.7
    }

    #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary,
    #onetrust-banner-sdk button.ot-sdk-button-primary,
    #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary,
    #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary,
    #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary,
    #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary,
    #onetrust-pc-sdk button.ot-sdk-button-primary,
    #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary,
    #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary,
    #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary,
    #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary,
    #ot-sdk-cookie-policy button.ot-sdk-button-primary,
    #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary,
    #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary,
    #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary {
      color: #fff;
      background-color: #33c3f0;
      border-color: #33c3f0
    }

    #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
    #onetrust-banner-sdk button.ot-sdk-button-primary:hover,
    #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:hover,
    #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:hover,
    #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:hover,
    #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
    #onetrust-banner-sdk button.ot-sdk-button-primary:focus,
    #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:focus,
    #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:focus,
    #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:focus,
    #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
    #onetrust-pc-sdk button.ot-sdk-button-primary:hover,
    #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:hover,
    #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:hover,
    #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:hover,
    #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
    #onetrust-pc-sdk button.ot-sdk-button-primary:focus,
    #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:focus,
    #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:focus,
    #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:focus,
    #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:hover,
    #ot-sdk-cookie-policy button.ot-sdk-button-primary:hover,
    #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:hover,
    #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:hover,
    #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:hover,
    #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:focus,
    #ot-sdk-cookie-policy button.ot-sdk-button-primary:focus,
    #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:focus,
    #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:focus,
    #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:focus {
      color: #fff;
      background-color: #1eaedb;
      border-color: #1eaedb
    }

    #onetrust-banner-sdk input[type="email"],
    #onetrust-banner-sdk input[type="number"],
    #onetrust-banner-sdk input[type="search"],
    #onetrust-banner-sdk input[type="text"],
    #onetrust-banner-sdk input[type="tel"],
    #onetrust-banner-sdk input[type="url"],
    #onetrust-banner-sdk input[type="password"],
    #onetrust-banner-sdk textarea,
    #onetrust-banner-sdk select,
    #onetrust-pc-sdk input[type="email"],
    #onetrust-pc-sdk input[type="number"],
    #onetrust-pc-sdk input[type="search"],
    #onetrust-pc-sdk input[type="text"],
    #onetrust-pc-sdk input[type="tel"],
    #onetrust-pc-sdk input[type="url"],
    #onetrust-pc-sdk input[type="password"],
    #onetrust-pc-sdk textarea,
    #onetrust-pc-sdk select,
    #ot-sdk-cookie-policy input[type="email"],
    #ot-sdk-cookie-policy input[type="number"],
    #ot-sdk-cookie-policy input[type="search"],
    #ot-sdk-cookie-policy input[type="text"],
    #ot-sdk-cookie-policy input[type="tel"],
    #ot-sdk-cookie-policy input[type="url"],
    #ot-sdk-cookie-policy input[type="password"],
    #ot-sdk-cookie-policy textarea,
    #ot-sdk-cookie-policy select {
      height: 38px;
      padding: 6px 10px;
      background-color: #fff;
      border: 1px solid #d1d1d1;
      border-radius: 4px;
      box-shadow: none;
      box-sizing: border-box
    }

    #onetrust-banner-sdk input[type="email"],
    #onetrust-banner-sdk input[type="number"],
    #onetrust-banner-sdk input[type="search"],
    #onetrust-banner-sdk input[type="text"],
    #onetrust-banner-sdk input[type="tel"],
    #onetrust-banner-sdk input[type="url"],
    #onetrust-banner-sdk input[type="password"],
    #onetrust-banner-sdk textarea,
    #onetrust-pc-sdk input[type="email"],
    #onetrust-pc-sdk input[type="number"],
    #onetrust-pc-sdk input[type="search"],
    #onetrust-pc-sdk input[type="text"],
    #onetrust-pc-sdk input[type="tel"],
    #onetrust-pc-sdk input[type="url"],
    #onetrust-pc-sdk input[type="password"],
    #onetrust-pc-sdk textarea,
    #ot-sdk-cookie-policy input[type="email"],
    #ot-sdk-cookie-policy input[type="number"],
    #ot-sdk-cookie-policy input[type="search"],
    #ot-sdk-cookie-policy input[type="text"],
    #ot-sdk-cookie-policy input[type="tel"],
    #ot-sdk-cookie-policy input[type="url"],
    #ot-sdk-cookie-policy input[type="password"],
    #ot-sdk-cookie-policy textarea {
      -webkit-appearance: none;
      -moz-appearance: none;
      appearance: none
    }

    #onetrust-banner-sdk textarea,
    #onetrust-pc-sdk textarea,
    #ot-sdk-cookie-policy textarea {
      min-height: 65px;
      padding-top: 6px;
      padding-bottom: 6px
    }

    #onetrust-banner-sdk input[type="email"]:focus,
    #onetrust-banner-sdk input[type="number"]:focus,
    #onetrust-banner-sdk input[type="search"]:focus,
    #onetrust-banner-sdk input[type="text"]:focus,
    #onetrust-banner-sdk input[type="tel"]:focus,
    #onetrust-banner-sdk input[type="url"]:focus,
    #onetrust-banner-sdk input[type="password"]:focus,
    #onetrust-banner-sdk textarea:focus,
    #onetrust-banner-sdk select:focus,
    #onetrust-pc-sdk input[type="email"]:focus,
    #onetrust-pc-sdk input[type="number"]:focus,
    #onetrust-pc-sdk input[type="search"]:focus,
    #onetrust-pc-sdk input[type="text"]:focus,
    #onetrust-pc-sdk input[type="tel"]:focus,
    #onetrust-pc-sdk input[type="url"]:focus,
    #onetrust-pc-sdk input[type="password"]:focus,
    #onetrust-pc-sdk textarea:focus,
    #onetrust-pc-sdk select:focus,
    #ot-sdk-cookie-policy input[type="email"]:focus,
    #ot-sdk-cookie-policy input[type="number"]:focus,
    #ot-sdk-cookie-policy input[type="search"]:focus,
    #ot-sdk-cookie-policy input[type="text"]:focus,
    #ot-sdk-cookie-policy input[type="tel"]:focus,
    #ot-sdk-cookie-policy input[type="url"]:focus,
    #ot-sdk-cookie-policy input[type="password"]:focus,
    #ot-sdk-cookie-policy textarea:focus,
    #ot-sdk-cookie-policy select:focus {
      border: 1px solid #33c3f0;
      outline: 0
    }

    #onetrust-banner-sdk label,
    #onetrust-banner-sdk legend,
    #onetrust-pc-sdk label,
    #onetrust-pc-sdk legend,
    #ot-sdk-cookie-policy label,
    #ot-sdk-cookie-policy legend {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 600
    }

    #onetrust-banner-sdk fieldset,
    #onetrust-pc-sdk fieldset,
    #ot-sdk-cookie-policy fieldset {
      padding: 0;
      border-width: 0
    }

    #onetrust-banner-sdk input[type="checkbox"],
    #onetrust-banner-sdk input[type="radio"],
    #onetrust-pc-sdk input[type="checkbox"],
    #onetrust-pc-sdk input[type="radio"],
    #ot-sdk-cookie-policy input[type="checkbox"],
    #ot-sdk-cookie-policy input[type="radio"] {
      display: inline
    }

    #onetrust-banner-sdk label>.label-body,
    #onetrust-pc-sdk label>.label-body,
    #ot-sdk-cookie-policy label>.label-body {
      display: inline-block;
      margin-left: 0.5rem;
      font-weight: normal
    }

    #onetrust-banner-sdk ul,
    #onetrust-pc-sdk ul,
    #ot-sdk-cookie-policy ul {
      list-style: circle inside
    }

    #onetrust-banner-sdk ol,
    #onetrust-pc-sdk ol,
    #ot-sdk-cookie-policy ol {
      list-style: decimal inside
    }

    #onetrust-banner-sdk ol,
    #onetrust-banner-sdk ul,
    #onetrust-pc-sdk ol,
    #onetrust-pc-sdk ul,
    #ot-sdk-cookie-policy ol,
    #ot-sdk-cookie-policy ul {
      padding-left: 0;
      margin-top: 0
    }

    #onetrust-banner-sdk ul ul,
    #onetrust-banner-sdk ul ol,
    #onetrust-banner-sdk ol ol,
    #onetrust-banner-sdk ol ul,
    #onetrust-pc-sdk ul ul,
    #onetrust-pc-sdk ul ol,
    #onetrust-pc-sdk ol ol,
    #onetrust-pc-sdk ol ul,
    #ot-sdk-cookie-policy ul ul,
    #ot-sdk-cookie-policy ul ol,
    #ot-sdk-cookie-policy ol ol,
    #ot-sdk-cookie-policy ol ul {
      margin: 1.5rem 0 1.5rem 3rem;
      font-size: 90%
    }

    #onetrust-banner-sdk li,
    #onetrust-pc-sdk li,
    #ot-sdk-cookie-policy li {
      margin-bottom: 1rem
    }

    #onetrust-banner-sdk code,
    #onetrust-pc-sdk code,
    #ot-sdk-cookie-policy code {
      padding: 0.2rem 0.5rem;
      margin: 0 0.2rem;
      font-size: 90%;
      white-space: nowrap;
      background: #f1f1f1;
      border: 1px solid #e1e1e1;
      border-radius: 4px
    }

    #onetrust-banner-sdk pre>code,
    #onetrust-pc-sdk pre>code,
    #ot-sdk-cookie-policy pre>code {
      display: block;
      padding: 1rem 1.5rem;
      white-space: pre
    }

    #onetrust-banner-sdk th,
    #onetrust-banner-sdk td,
    #onetrust-pc-sdk th,
    #onetrust-pc-sdk td,
    #ot-sdk-cookie-policy th,
    #ot-sdk-cookie-policy td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #e1e1e1
    }

    #onetrust-banner-sdk .ot-sdk-u-full-width,
    #onetrust-pc-sdk .ot-sdk-u-full-width,
    #ot-sdk-cookie-policy .ot-sdk-u-full-width {
      width: 100%;
      box-sizing: border-box
    }

    #onetrust-banner-sdk .ot-sdk-u-max-full-width,
    #onetrust-pc-sdk .ot-sdk-u-max-full-width,
    #ot-sdk-cookie-policy .ot-sdk-u-max-full-width {
      max-width: 100%;
      box-sizing: border-box
    }

    #onetrust-banner-sdk .ot-sdk-u-pull-right,
    #onetrust-pc-sdk .ot-sdk-u-pull-right,
    #ot-sdk-cookie-policy .ot-sdk-u-pull-right {
      float: right
    }

    #onetrust-banner-sdk .ot-sdk-u-pull-left,
    #onetrust-pc-sdk .ot-sdk-u-pull-left,
    #ot-sdk-cookie-policy .ot-sdk-u-pull-left {
      float: left
    }

    #onetrust-banner-sdk hr,
    #onetrust-pc-sdk hr,
    #ot-sdk-cookie-policy hr {
      margin-top: 3rem;
      margin-bottom: 3.5rem;
      border-width: 0;
      border-top: 1px solid #e1e1e1
    }

    #onetrust-banner-sdk .ot-sdk-container:after,
    #onetrust-banner-sdk .ot-sdk-row:after,
    #onetrust-banner-sdk .ot-sdk-u-cf,
    #onetrust-pc-sdk .ot-sdk-container:after,
    #onetrust-pc-sdk .ot-sdk-row:after,
    #onetrust-pc-sdk .ot-sdk-u-cf,
    #ot-sdk-cookie-policy .ot-sdk-container:after,
    #ot-sdk-cookie-policy .ot-sdk-row:after,
    #ot-sdk-cookie-policy .ot-sdk-u-cf {
      content: "";
      display: table;
      clear: both
    }

    #onetrust-banner-sdk .ot-sdk-row,
    #onetrust-pc-sdk .ot-sdk-row,
    #ot-sdk-cookie-policy .ot-sdk-row {
      margin: 0;
      max-width: none;
      display: block;
      margin: 0
    }

    #onetrust-dark-filter {
      background: rgba(0, 0, 0, .5);
      z-index: 2147483646;
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0
    }

    #onetrust-banner-sdk {
      box-shadow: 0 0 18px rgba(0, 0, 0, .2)
    }

    #onetrust-banner-sdk.otCenterRounded {
      z-index: 2147483645;
      top: 10%;
      position: fixed;
      right: 0;
      background-color: #fff;
      width: 60%;
      max-width: 650px;
      border-radius: 2.5px;
      left: 1em;
      margin: 0 auto;
      font-size: 14px;
      max-height: 90%;
      overflow-x: hidden;
      overflow-y: auto
    }

    #onetrust-banner-sdk::-webkit-scrollbar {
      width: 11px
    }

    #onetrust-banner-sdk::-webkit-scrollbar-thumb {
      border-radius: 10px;
      background: #c1c1c1
    }

    #onetrust-banner-sdk {
      scrollbar-arrow-color: #c1c1c1;
      scrollbar-darkshadow-color: #c1c1c1;
      scrollbar-face-color: #c1c1c1;
      scrollbar-shadow-color: #c1c1c1
    }

    #onetrust-banner-sdk h3,
    #onetrust-banner-sdk p {
      color: dimgray
    }

    #onetrust-banner-sdk #onetrust-policy {
      margin-top: 20px
    }

    #onetrust-banner-sdk #onetrust-policy-title {
      float: left;
      text-align: left;
      font-size: 1em;
      line-height: 1.4;
      margin-bottom: 0;
      padding: 0 0 10px 30px;
      width: calc(100% - 90px)
    }

    #onetrust-banner-sdk #onetrust-policy-text,
    #onetrust-banner-sdk .ot-b-addl-desc {
      clear: both;
      float: left;
      margin: 0 30px 10px 30px;
      font-size: .813em;
      line-height: 1.5
    }

    #onetrust-banner-sdk #onetrust-policy-text *,
    #onetrust-banner-sdk .ot-b-addl-desc * {
      line-height: inherit;
      font-size: inherit;
      margin: 0
    }

    #onetrust-banner-sdk .ot-b-addl-desc {
      display: block
    }

    #onetrust-banner-sdk #onetrust-button-group-parent {
      padding: 15px 30px;
      text-align: center
    }

    #onetrust-banner-sdk #onetrust-button-group-parent:not(.has-reject-all-button) #onetrust-button-group {
      text-align: right
    }

    #onetrust-banner-sdk #onetrust-button-group {
      text-align: center;
      display: inline-block;
      width: 100%
    }

    #onetrust-banner-sdk #onetrust-reject-all-handler,
    #onetrust-banner-sdk #onetrust-pc-btn-handler {
      margin-right: 1em
    }

    #onetrust-banner-sdk #onetrust-pc-btn-handler {
      border: 1px solid #6cc04a;
      max-width: 45%
    }

    #onetrust-banner-sdk .banner-actions-container {
      float: right;
      width: 50%
    }

    #onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link {
      background-color: #fff;
      border: none;
      color: #6cc04a;
      text-decoration: underline;
      padding-left: 0
    }

    #onetrust-banner-sdk #onetrust-accept-btn-handler,
    #onetrust-banner-sdk #onetrust-reject-all-handler,
    #onetrust-banner-sdk #onetrust-pc-btn-handler {
      background-color: #6cc04a;
      color: #fff;
      border-color: #6cc04a;
      min-width: 135px;
      padding: 12px 10px;
      letter-spacing: .05em;
      line-height: 1.4;
      font-size: .813em;
      font-weight: 600;
      height: auto;
      white-space: normal;
      word-break: break-word;
      word-wrap: break-word
    }

    #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler {
      float: left;
      max-width: calc(40% - 18px)
    }

    #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link {
      text-align: left;
      margin-right: 0
    }

    #onetrust-banner-sdk .has-reject-all-button .banner-actions-container {
      max-width: 60%;
      width: auto
    }

    #onetrust-banner-sdk .ot-close-icon {
      width: .8em;
      height: 18px;
      border: none;
      display: inline-block;
      padding: 0
    }

    #onetrust-banner-sdk #onetrust-close-btn-container {
      float: right;
      margin-right: 20px
    }

    #onetrust-banner-sdk .banner_logo {
      display: none
    }

    #onetrust-banner-sdk #banner-options {
      float: left;
      padding: 0 30px;
      width: calc(100% - 90px)
    }

    #onetrust-banner-sdk #banner-options label {
      margin: 0;
      display: inline-block
    }

    #onetrust-banner-sdk .banner-option {
      margin-bottom: 10px
    }

    #onetrust-banner-sdk .banner-option-input {
      position: absolute;
      cursor: pointer;
      width: auto;
      height: 20px;
      opacity: 0
    }

    #onetrust-banner-sdk .banner-option-input:checked~label .ot-arrow-container {
      transform: rotate(90deg)
    }

    #onetrust-banner-sdk .banner-option-input:checked~.banner-option-details {
      height: auto;
      display: block
    }

    #onetrust-banner-sdk .banner-option-header {
      cursor: pointer;
      display: inline-block
    }

    #onetrust-banner-sdk .banner-option-header :first-child {
      font-size: .82em;
      line-height: 1.4;
      color: dimgray;
      font-weight: bold;
      float: left
    }

    #onetrust-banner-sdk .ot-arrow-container,
    #onetrust-banner-sdk .banner-option-details {
      transition: all 300ms ease-in 0s;
      -webkit-transition: all 300ms ease-in 0s;
      -moz-transition: all 300ms ease-in 0s;
      -o-transition: all 300ms ease-in 0s
    }

    #onetrust-banner-sdk .ot-arrow-container {
      display: inline-block;
      border-top: 6px solid transparent;
      border-bottom: 6px solid transparent;
      border-left: 6px solid dimgray;
      margin-left: 10px;
      margin-top: 2px
    }

    #onetrust-banner-sdk .banner-option-details {
      display: none;
      font-size: .83em;
      line-height: 1.5;
      height: 0px;
      padding: 10px 10px 5px 10px
    }

    #onetrust-banner-sdk .banner-option-details * {
      font-size: inherit;
      line-height: inherit;
      color: dimgray
    }

    #onetrust-banner-sdk .ot-dpd-container {
      float: left;
      margin: 0 30px 10px 30px
    }

    #onetrust-banner-sdk .ot-dpd-title {
      font-weight: bold;
      padding-bottom: 10px
    }

    #onetrust-banner-sdk .ot-dpd-title {
      font-size: 1em;
      line-height: 1.4
    }

    #onetrust-banner-sdk .ot-dpd-desc {
      font-size: .813em;
      line-height: 1.5;
      margin-bottom: 0
    }

    #onetrust-banner-sdk .ot-dpd-desc * {
      margin: 0
    }

    #onetrust-banner-sdk .onetrust-vendors-list-handler {
      display: block;
      margin-left: 0px;
      margin-top: 5px
    }

    #onetrust-banner-sdk :not(.ot-dpd-desc)>.ot-b-addl-desc {
      float: left;
      margin: 0 30px 10px 30px
    }

    #onetrust-banner-sdk .ot-dpd-desc>.ot-b-addl-desc {
      margin-top: 10px;
      margin-bottom: 10px;
      font-size: 1em;
      line-height: 1.5;
      float: none
    }

    #onetrust-banner-sdk #onetrust-policy-text a {
      font-weight: bold;
      margin-left: 5px
    }

    @media only screen and (max-width: 425px) {

      #onetrust-banner-sdk #onetrust-accept-btn-handler,
      #onetrust-banner-sdk #onetrust-reject-all-handler,
      #onetrust-banner-sdk #onetrust-pc-btn-handler {
        width: 100%;
        margin-bottom: 10px
      }

      #onetrust-banner-sdk #onetrust-pc-btn-handler,
      #onetrust-banner-sdk #onetrust-reject-all-handler {
        margin-right: 0
      }

      #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link {
        text-align: center
      }

      #onetrust-banner-sdk .banner-actions-container,
      #onetrust-banner-sdk #onetrust-pc-btn-handler {
        width: 100%;
        max-width: none
      }

      #onetrust-banner-sdk.otCenterRounded {
        left: 0;
        width: 95%;
        top: 50%;
        transform: translateY(-50%);
        -webkit-transform: translateY(-50%)
      }
    }

    @media only screen and (max-width: 600px) {
      #onetrust-banner-sdk .ot-sdk-container {
        width: auto;
        padding: 0
      }

      #onetrust-banner-sdk #onetrust-policy-title {
        padding: 0 22px 10px 22px
      }

      #onetrust-banner-sdk #onetrust-policy-text,
      #onetrust-banner-sdk :not(.ot-dpd-desc)>.ot-b-addl-desc,
      #onetrust-banner-sdk .ot-dpd-container {
        margin: 0 22px 10px 22px;
        width: calc(100% - 44px)
      }

      #onetrust-banner-sdk #onetrust-button-group-parent {
        padding: 15px 22px
      }

      #onetrust-banner-sdk #banner-options {
        padding: 0 22px;
        width: calc(100% - 44px)
      }

      #onetrust-banner-sdk .banner-option {
        margin-bottom: 6px
      }

      #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler {
        float: none;
        max-width: 100%
      }

      #onetrust-banner-sdk .has-reject-all-button .banner-actions-container {
        width: 100%;
        text-align: center;
        max-width: 100%
      }
    }

    @media only screen and (min-width: 426px)and (max-width: 896px) {
      #onetrust-banner-sdk.otCenterRounded {
        left: 0;
        top: 15%;
        transform: translateY(-13%);
        -webkit-transform: translateY(-13%);
        max-width: 600px;
        width: 95%
      }
    }

    #onetrust-consent-sdk #onetrust-banner-sdk {
      background-color: #FFFFFF;
    }

    #onetrust-consent-sdk #onetrust-policy-title,
    #onetrust-consent-sdk #onetrust-policy-text,
    #onetrust-consent-sdk .ot-b-addl-desc,
    #onetrust-consent-sdk .ot-dpd-desc,
    #onetrust-consent-sdk .ot-dpd-title,
    #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),
    #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),
    #onetrust-consent-sdk #onetrust-banner-sdk #banner-options * {
      color: #696969;
    }

    #onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {
      background-color: #E9E9E9;
    }

    #onetrust-consent-sdk #onetrust-accept-btn-handler,
    #onetrust-banner-sdk #onetrust-reject-all-handler {
      background-color: #6CC04A;
      border-color: #6CC04A;
      color: #FFFFFF;
    }

    #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {
      border-color: #FFFFFF;
      background-color: #FFFFFF;
      color: #6CC04A
    }

    #onetrust-consent-sdk #onetrust-pc-btn-handler {
      color: #6CC04A;
      border-color: #6CC04A;
      background-color: #FFFFFF;
    }

    #onetrust-pc-sdk.otPcPopup *,
    #onetrust-pc-sdk.otPcPopup ::after,
    #onetrust-pc-sdk.otPcPopup ::before {
      box-sizing: content-box
    }

    #onetrust-pc-sdk.otPcPopup.ot-sdk-container {
      padding-right: 0
    }

    #onetrust-pc-sdk.otPcPopup {
      position: fixed;
      bottom: 3em;
      left: 3em;
      background-color: #fff;
      width: 25%;
      max-width: 400px;
      min-width: 400px;
      border-radius: 6.5px;
      height: 83%;
      max-height: 800px;
      padding-left: 0;
      -webkit-font-smoothing: auto;
      -webkit-box-shadow: 0px 2px 10px -3px #999;
      -moz-box-shadow: 0px 2px 10px -3px #999;
      box-shadow: 0px 2px 10px -3px #999
    }

    #onetrust-pc-sdk {
      z-index: 2147483647
    }

    #onetrust-pc-sdk .ot-hide-tgl {
      visibility: hidden
    }

    #onetrust-pc-sdk .ot-hide-tgl * {
      visibility: hidden
    }

    #onetrust-pc-sdk #pc-title {
      font-size: 1.6em;
      margin-bottom: 10px;
      color: #2c3643
    }

    #onetrust-pc-sdk #pc-policy-text {
      font-size: .7em;
      line-height: 1.4;
      color: dimgray
    }

    #onetrust-pc-sdk #pc-policy-text a {
      font-size: 1em
    }

    #onetrust-pc-sdk #pc-policy-text * {
      font-size: inherit
    }

    #onetrust-pc-sdk #pc-policy-text ul li {
      padding: 10px
    }

    #onetrust-pc-sdk p {
      font-size: .7em;
      line-height: 1.6;
      color: dimgray
    }

    #onetrust-pc-sdk a {
      color: #3860be;
      cursor: pointer
    }

    #onetrust-pc-sdk a:hover {
      color: #67b2fc
    }

    #onetrust-pc-sdk label {
      margin-bottom: 0
    }

    #onetrust-pc-sdk .ot-close-icon {
      background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjQ3Ljk3MSIgaGVpZ2h0PSI0Ny45NzEiIHZpZXdCb3g9IjAgMCA0Ny45NzEgNDcuOTcxIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA0Ny45NzEgNDcuOTcxOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PGc+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI4LjIyOCwyMy45ODZMNDcuMDkyLDUuMTIyYzEuMTcyLTEuMTcxLDEuMTcyLTMuMDcxLDAtNC4yNDJjLTEuMTcyLTEuMTcyLTMuMDctMS4xNzItNC4yNDIsMEwyMy45ODYsMTkuNzQ0TDUuMTIxLDAuODhjLTEuMTcyLTEuMTcyLTMuMDctMS4xNzItNC4yNDIsMGMtMS4xNzIsMS4xNzEtMS4xNzIsMy4wNzEsMCw0LjI0MmwxOC44NjUsMTguODY0TDAuODc5LDQyLjg1Yy0xLjE3MiwxLjE3MS0xLjE3MiwzLjA3MSwwLDQuMjQyQzEuNDY1LDQ3LjY3NywyLjIzMyw0Ny45NywzLDQ3Ljk3czEuNTM1LTAuMjkzLDIuMTIxLTAuODc5bDE4Ljg2NS0xOC44NjRMNDIuODUsNDcuMDkxYzAuNTg2LDAuNTg2LDEuMzU0LDAuODc5LDIuMTIxLDAuODc5czEuNTM1LTAuMjkzLDIuMTIxLTAuODc5YzEuMTcyLTEuMTcxLDEuMTcyLTMuMDcxLDAtNC4yNDJMMjguMjI4LDIzLjk4NnoiLz48L2c+PC9zdmc+");
      background-size: 22px;
      background-repeat: no-repeat;
      background-position: center
    }

    #onetrust-pc-sdk .back-btn-handler p {
      font-weight: bold
    }

    #onetrust-pc-sdk #vendors-list-btn {
      font-size: .8em;
      text-decoration: none;
      font-weight: bold
    }

    #onetrust-pc-sdk #ot-content {
      position: absolute;
      overflow-y: scroll;
      padding-right: 10px;
      top: 30px;
      bottom: 40px;
      margin-right: 7px;
      margin-left: 30px;
      width: calc(100% - 47px)
    }

    #onetrust-pc-sdk #ot-content::-webkit-scrollbar-track,
    #onetrust-pc-sdk #ot-options::-webkit-scrollbar-track,
    #onetrust-pc-sdk #vendor-list-content::-webkit-scrollbar-track {
      margin-right: 20px
    }

    #onetrust-pc-sdk #ot-content::-webkit-scrollbar,
    #onetrust-pc-sdk #ot-options::-webkit-scrollbar,
    #onetrust-pc-sdk #vendor-list-content::-webkit-scrollbar {
      width: 11px
    }

    #onetrust-pc-sdk #ot-content::-webkit-scrollbar-thumb,
    #onetrust-pc-sdk #ot-options::-webkit-scrollbar-thumb,
    #onetrust-pc-sdk #vendor-list-content::-webkit-scrollbar-thumb {
      border-radius: 10px;
      background: #d8d8d8
    }

    #onetrust-pc-sdk #ot-content,
    #onetrust-pc-sdk #vendor-list-content,
    #onetrust-pc-sdk #ot-options {
      scrollbar-arrow-color: #d8d8d8;
      scrollbar-darkshadow-color: #d8d8d8;
      scrollbar-face-color: #d8d8d8;
      scrollbar-shadow-color: #d8d8d8
    }

    #onetrust-pc-sdk #vendor-list-container {
      margin-bottom: 10px
    }

    #onetrust-pc-sdk .privacy-notice-link {
      text-decoration: underline
    }

    #onetrust-pc-sdk .pc-logo {
      height: 40px;
      width: 120px;
      margin-bottom: 10px
    }

    #onetrust-pc-sdk .ot-pc-footer-logo {
      position: absolute;
      bottom: -1px;
      right: 20px
    }

    #onetrust-pc-sdk .ot-pc-footer-logo svg {
      width: 152px;
      height: 25px
    }

    #onetrust-pc-sdk .checkbox {
      position: relative;
      display: inline-block
    }

    #onetrust-pc-sdk .checkbox label {
      width: 90px;
      height: 42px;
      background: #ccc;
      position: relative;
      display: inline-block;
      border-radius: 46px;
      transition: .4s;
      z-index: 2
    }

    #onetrust-pc-sdk .checkbox label:after {
      content: "";
      position: absolute;
      width: 50px;
      height: 50px;
      border-radius: 100%;
      left: 0;
      top: -5px;
      z-index: 2;
      background: #fff;
      transition: .4s
    }

    #onetrust-pc-sdk .checkbox input {
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      z-index: 5;
      opacity: 0;
      cursor: pointer
    }

    #onetrust-pc-sdk .checkbox input:checked+label:after {
      left: 40px
    }

    #onetrust-pc-sdk .checkbox .category-switch-handler {
      height: 0
    }

    #onetrust-pc-sdk .checkbox:after,
    #onetrust-pc-sdk .checkbox:before {
      -webkit-font-feature-settings: normal;
      font-feature-settings: normal;
      -webkit-font-kerning: auto;
      font-kerning: auto;
      -webkit-font-language-override: normal;
      font-language-override: normal;
      font-stretch: normal;
      font-style: normal;
      font-synthesis: weight style;
      font-variant: normal;
      font-weight: normal;
      text-rendering: auto
    }

    #onetrust-pc-sdk .ot-toggle .checkbox {
      z-index: 2
    }

    #onetrust-pc-sdk .ot-toggle .checkbox label {
      background: #d6d6d6;
      border: none;
      height: 10px;
      width: 35px
    }

    #onetrust-pc-sdk .ot-toggle .checkbox label:after {
      background: #7b7b7b;
      width: 20px;
      height: 20px
    }

    #onetrust-pc-sdk .ot-toggle .checkbox input:checked+label {
      background: #cddcf2
    }

    #onetrust-pc-sdk .ot-toggle .checkbox input:checked+label:after {
      background: #4285f4;
      left: 16px
    }

    #onetrust-pc-sdk .ot-toggle-group,
    #onetrust-pc-sdk .ot-toggle,
    #onetrust-pc-sdk .ot-arrow-container {
      float: left;
      display: inline-block
    }

    #onetrust-pc-sdk .ot-toggle-group {
      width: auto;
      float: right
    }

    #onetrust-pc-sdk .ot-toggle-group.ot-always-active {
      width: 40%
    }

    #onetrust-pc-sdk .ot-arrow {
      width: 10px;
      margin-left: 15px;
      transition: all 300ms ease-in 0s;
      -webkit-transition: all 300ms ease-in 0s;
      -moz-transition: all 300ms ease-in 0s;
      -o-transition: all 300ms ease-in 0s
    }

    #onetrust-pc-sdk button.ot-pill {
      border-radius: 20px;
      font-size: .75em;
      text-align: center;
      background-color: #68b631;
      border-color: #68b631;
      font-weight: 600;
      box-shadow: 0 0 10px 1px #cce1ff;
      width: 170px;
      max-width: 180px;
      color: #fff;
      height: auto;
      white-space: normal;
      word-wrap: break-word;
      padding: 10px;
      line-height: 1.2;
      letter-spacing: .05em;
      margin: 1rem 0 0 0
    }

    #onetrust-pc-sdk button.ot-pill#filter-apply-handler {
      margin: 0
    }

    #onetrust-pc-sdk .ot-arrow-container {
      margin-top: 1.2px;
      float: right
    }

    #onetrust-pc-sdk .ot-arrow-container img {
      -webkit-transition: all 300ms ease-in 0s;
      -moz-transition: all 300ms ease-in 0s;
      -o-transition: all 300ms ease-in 0s;
      transition: all 300ms ease-in 0s
    }

    #onetrust-pc-sdk .ot-arrow-container svg {
      height: 10px;
      width: 10px
    }

    #onetrust-pc-sdk .ot-always-active {
      float: left;
      line-height: 1.3;
      font-size: .9em;
      position: relative;
      top: 3px;
      color: #3860be;
      font-weight: bold
    }

    #onetrust-pc-sdk.ot-accordions-pc .category-item {
      padding: 0px
    }

    #onetrust-pc-sdk.ot-accordions-pc .accordion-header,
    #onetrust-pc-sdk.ot-accordions-pc .accordion-text,
    #onetrust-pc-sdk.ot-accordions-pc .accordion-text-description,
    #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container,
    #onetrust-pc-sdk.ot-accordions-pc .ot-accordion-group-pc-container,
    #onetrust-pc-sdk.ot-accordions-pc .ot-accordion-group-pc-container+.ot-leg-btn-container {
      padding-left: 20px;
      padding-right: 15px
    }

    #onetrust-pc-sdk.ot-accordions-pc .ot-accordion-group-pc-container+.ot-leg-btn-container {
      width: calc(100% - 35px);
      margin-bottom: 10px;
      margin-top: 0
    }

    #onetrust-pc-sdk.ot-accordions-pc .accordion-header {
      padding-top: 14px;
      margin-top: 1px;
      padding-bottom: 15px
    }

    #onetrust-pc-sdk.ot-accordions-pc ul li input[type=checkbox]:not(:checked)~.accordion-text {
      width: auto
    }

    #onetrust-pc-sdk.ot-accordions-pc .accordion-text {
      width: 100%;
      padding: 0px
    }

    #onetrust-pc-sdk.ot-accordions-pc input[type=checkbox]:checked~.accordion-text {
      border-top: 1px solid #c7c7c7;
      margin-top: 0px;
      padding: 0px;
      width: 100%
    }

    #onetrust-pc-sdk.ot-accordions-pc .accordion-text-description {
      padding-top: 10px;
      padding-bottom: 7.5px
    }

    #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container {
      padding-bottom: 7.5px;
      width: calc(100% - 35px);
      margin: 0px;
      padding-top: 7.5px;
      border-top: 1px solid #d3d3d3
    }

    #onetrust-pc-sdk.ot-accordions-pc .category-vendors-list-container+.cookie-subgroups-container {
      border-top: none
    }

    #onetrust-pc-sdk.ot-accordions-pc input[type=checkbox]:checked~.accordion-text.ot-accordion-pc-container {
      width: auto
    }

    #onetrust-pc-sdk.ot-accordions-pc .ot-accordion-group-pc-container {
      padding-top: 10px
    }

    #onetrust-pc-sdk.ot-accordions-pc .ot-accordion-group-pc-container+.category-vendors-list-container {
      margin-top: 0px
    }

    #onetrust-pc-sdk .ot-toggle.ot-hide-tgl {
      visibility: hidden
    }

    #onetrust-pc-sdk .ot-toggle.ot-hide-tgl * {
      visibility: hidden
    }

    #onetrust-pc-sdk.ot-accordions-pc ul ul.cookie-subgroups li.cookie-subgroup {
      margin: 0
    }

    #onetrust-pc-sdk .ot-accordion-pc-container>.cookie-subgroups-container {
      border-top: none
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups .cookie-subgroup {
      margin: 0px
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups .cookie-subgroup>h6 {
      width: 60%
    }

    #onetrust-pc-sdk .ot-accordion-pc-container ul.cookie-subgroups .cookie-subgroup-toggle {
      width: 55px
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-container {
      margin: 0px;
      padding-bottom: 7.5px;
      padding-top: 7.5px;
      border-top: 1px solid #d3d3d3
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-container:first-child {
      border: none
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container>ul,
    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal>ul {
      margin: 0px;
      list-style: disc;
      padding-left: 15px
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container,
    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container>ul,
    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal,
    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal>ul {
      color: gray
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container ul:first-child,
    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal ul:first-child {
      margin-bottom: 5px
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container,
    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container li,
    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal,
    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal li {
      font-size: .7rem
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal,
    #onetrust-pc-sdk .ot-accordion-pc-container .cookie-subgroups-description-legal ul:first-child {
      margin-top: 5px
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container {
      width: calc(100% - 35px);
      padding-bottom: 10px
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container ul:first-child {
      margin-bottom: 10px
    }

    #onetrust-pc-sdk .ot-accordion-pc-container .ot-accordion-group-pc-container li {
      border: none;
      padding: 0
    }

    #onetrust-pc-sdk .ot-always-active-group {
      overflow: hidden
    }

    #onetrust-pc-sdk .ot-always-active-group .ot-always-active {
      width: calc(100% - 25px);
      text-align: right
    }

    #onetrust-pc-sdk .ot-always-active-group .ot-toggle-group {
      max-width: 45%
    }

    #onetrust-pc-sdk .ot-always-active-subgroup {
      max-width: 40%
    }

    #onetrust-pc-sdk .ot-always-active-subgroup .ot-always-active {
      text-align: right
    }

    #onetrust-pc-sdk.ot-leg-opt-out:not(.ot-leg-btn) #vendors-list:not(.hosts-list) #select-all-container {
      width: 100%;
      max-width: 100%
    }

    #onetrust-pc-sdk.ot-leg-opt-out:not(.ot-leg-btn) #vendors-list:not(.hosts-list) #select-all-container .ot-checkbox {
      right: 10px
    }

    #onetrust-pc-sdk.ot-leg-opt-out:not(.ot-leg-btn) #select-all-container {
      display: block;
      float: none;
      clear: both
    }

    #onetrust-pc-sdk.ot-leg-opt-out:not(.ot-leg-btn) #select-all-container .ot-checkbox {
      margin: 0;
      position: relative
    }

    #onetrust-pc-sdk.ot-leg-opt-out .category-item {
      margin-top: 0px;
      border-top: 0px;
      border-radius: 2px;
      width: calc(100% - 2px);
      border-color: #e9e9e9
    }

    #onetrust-pc-sdk.ot-leg-opt-out .category-item:first-child {
      border-top: 1px solid #e9e9e9;
      margin-top: 10px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header {
      color: #77808e;
      overflow: hidden;
      padding-top: 7.5px;
      padding-bottom: 7.5px;
      width: calc(100% - 2px);
      border-radius: 2px;
      margin-top: 10px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header .leg-int-title {
      float: right;
      font-size: 13px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header span:first-child {
      max-width: 80px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header span:last-child {
      padding-right: 10px;
      max-width: 95px;
      text-align: center
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header.ot-leg-border-color {
      background-color: #f8f8f8;
      border: 1px solid #e9e9e9
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header.ot-leg-border-color span:first-child {
      text-align: left;
      width: 80px
    }

    #onetrust-pc-sdk.ot-leg-opt-out ul.cookie-subgroups li.cookie-subgroup>h6+.cookie-subgroup-toggle {
      padding-right: 20px;
      padding-left: 15px
    }

    #onetrust-pc-sdk.ot-leg-opt-out ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle {
      width: 35px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .accordion-header:not(.ot-always-active-group) h3+.ot-toggle-group {
      padding-left: 15px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-sel-all-hdr {
      position: relative;
      display: inline-block;
      width: 100%
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-hdr,
    #onetrust-pc-sdk.ot-leg-opt-out .consent-hdr {
      float: right;
      font-size: .8em
    }

    #onetrust-pc-sdk.ot-leg-opt-out .leg-int-hdr {
      position: relative;
      right: 45px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .consent-hdr {
      position: relative;
      right: 20px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .ot-vendor-consent-tgl {
      margin-left: 60px
    }

    #onetrust-pc-sdk.ot-leg-opt-out .ot-leg-int-tgl+.ot-arrow-container {
      margin-left: 81px
    }

    #onetrust-pc-sdk.ot-leg-opt-out #select-all-container .ot-checkbox {
      line-height: normal
    }

    #onetrust-pc-sdk.ot-leg-opt-out #select-all-vendors-input-container {
      right: 44px;
      position: relative;
      float: right;
      min-width: auto
    }

    #onetrust-pc-sdk.ot-leg-opt-out #select-all-vendors-leg-input-container {
      display: block;
      width: 21px;
      height: 20px;
      float: right;
      position: relative;
      right: 104px
    }

    #onetrust-pc-sdk.ot-leg-opt-out #select-all-vendors-leg-input-container input {
      position: absolute
    }

    #onetrust-pc-sdk.ot-leg-opt-out #select-all-vendors-leg-input-container label {
      position: absolute
    }

    #onetrust-pc-sdk.ot-leg-opt-out #vendors-list.hosts-list #select-all-container {
      float: right
    }

    #onetrust-pc-sdk.ot-leg-opt-out #vendors-list #vendors-list-container .ot-toggle-group {
      width: auto;
      top: auto
    }

    #onetrust-pc-sdk.ot-leg-opt-out #vendors-list #vendors-list-container .ot-checkbox {
      position: relative;
      display: inline-block;
      width: 20px;
      height: 25px
    }

    #onetrust-pc-sdk.ot-leg-opt-out #vendors-list #vendors-list-container .ot-checkbox label {
      position: absolute;
      padding: 0;
      width: 18px;
      height: 18px
    }

    #onetrust-pc-sdk.ot-leg-opt-out #vendors-list .vendor-options .consent-category {
      max-width: 100%
    }

    #onetrust-pc-sdk input:checked~.accordion-header .ot-arrow {
      transform: rotate(90deg);
      -o-transform: rotate(90deg);
      -ms-transform: rotate(90deg);
      -webkit-transform: rotate(90deg)
    }

    #onetrust-pc-sdk .btn-group {
      text-align: center;
      display: block
    }

    #onetrust-pc-sdk .btn-group button {
      border-radius: 20px
    }

    #onetrust-pc-sdk #pc-close-btn-container {
      position: absolute;
      float: left;
      left: -35px;
      bottom: 0;
      transform: translateY(50%);
      -o-transform: translateY(50%);
      -ms-transform: translateY(50%);
      -webkit-transform: translateY(50%);
      z-index: 2147483647
    }

    #onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon {
      text-align: center;
      display: block;
      border-radius: 50%;
      height: 64px;
      width: 64px;
      background-color: #2e3643;
      cursor: pointer;
      padding: 0;
      border: none
    }

    #onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon svg {
      width: 22px;
      height: 22px;
      transform: translateY(90%);
      -o-transform: translateY(90%);
      -ms-transform: translateY(90%);
      -webkit-transform: translateY(90%)
    }

    #onetrust-pc-sdk #close-pc-btn-handler:hover,
    #onetrust-pc-sdk #close-pc-btn-handler:focus {
      outline: none;
      opacity: .8
    }

    #onetrust-pc-sdk .category-vendors-list-btn,
    #onetrust-pc-sdk .category-vendors-list-btn+a,
    #onetrust-pc-sdk .category-host-list-btn {
      font-size: .7em;
      text-decoration: none;
      font-weight: bold;
      float: left
    }

    #onetrust-pc-sdk .category-vendors-list-btn+a {
      clear: none
    }

    #onetrust-pc-sdk .category-vendors-list-btn+a::after {
      content: "";
      height: 15px;
      width: 15px;
      background-repeat: no-repeat;
      margin-left: 5px;
      float: right;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 511.626 511.627'%3E%3Cg fill='%231276CE'%3E%3Cpath d='M392.857 292.354h-18.274c-2.669 0-4.859.855-6.563 2.573-1.718 1.708-2.573 3.897-2.573 6.563v91.361c0 12.563-4.47 23.315-13.415 32.262-8.945 8.945-19.701 13.414-32.264 13.414H82.224c-12.562 0-23.317-4.469-32.264-13.414-8.945-8.946-13.417-19.698-13.417-32.262V155.31c0-12.562 4.471-23.313 13.417-32.259 8.947-8.947 19.702-13.418 32.264-13.418h200.994c2.669 0 4.859-.859 6.57-2.57 1.711-1.713 2.566-3.9 2.566-6.567V82.221c0-2.662-.855-4.853-2.566-6.563-1.711-1.713-3.901-2.568-6.57-2.568H82.224c-22.648 0-42.016 8.042-58.102 24.125C8.042 113.297 0 132.665 0 155.313v237.542c0 22.647 8.042 42.018 24.123 58.095 16.086 16.084 35.454 24.13 58.102 24.13h237.543c22.647 0 42.017-8.046 58.101-24.13 16.085-16.077 24.127-35.447 24.127-58.095v-91.358c0-2.669-.856-4.859-2.574-6.57-1.713-1.718-3.903-2.573-6.565-2.573z'/%3E%3Cpath d='M506.199 41.971c-3.617-3.617-7.905-5.424-12.85-5.424H347.171c-4.948 0-9.233 1.807-12.847 5.424-3.617 3.615-5.428 7.898-5.428 12.847s1.811 9.233 5.428 12.85l50.247 50.248-186.147 186.151c-1.906 1.903-2.856 4.093-2.856 6.563 0 2.479.953 4.668 2.856 6.571l32.548 32.544c1.903 1.903 4.093 2.852 6.567 2.852s4.665-.948 6.567-2.852l186.148-186.148 50.251 50.248c3.614 3.617 7.898 5.426 12.847 5.426s9.233-1.809 12.851-5.426c3.617-3.616 5.424-7.898 5.424-12.847V54.818c-.001-4.952-1.814-9.232-5.428-12.847z'/%3E%3C/g%3E%3C/svg%3E")
    }

    #onetrust-pc-sdk .category-vendors-list-container,
    #onetrust-pc-sdk .category-host-list-container {
      margin-bottom: 15px
    }

    #onetrust-pc-sdk .category-host-list-container {
      display: inline-block;
      width: 100%
    }

    #onetrust-pc-sdk .back-btn-handler {
      font-size: 1em;
      text-decoration: none;
      font-weight: bold;
      color: #2e3644;
      display: table-cell;
      vertical-align: middle;
      width: auto
    }

    #onetrust-pc-sdk .back-btn-handler p {
      display: inline-block;
      word-wrap: break-word;
      margin-bottom: 0;
      max-width: 100px;
      vertical-align: middle;
      color: #2e3644;
      font-size: .9em
    }

    #onetrust-pc-sdk .back-btn-handler p:hover {
      opacity: .6
    }

    #onetrust-pc-sdk .back-btn-handler:focus {
      opacity: .6
    }

    #onetrust-pc-sdk #vendors-list-title {
      margin-bottom: 10px
    }

    #onetrust-pc-sdk #vendors-list-title * {
      font-size: inherit
    }

    #onetrust-pc-sdk #vendors-list-header {
      margin: 20px 15px 0 30px;
      height: 36px;
      width: 89%;
      display: inline-table
    }

    #onetrust-pc-sdk #vendors-list-header input {
      height: 35px;
      width: 220px;
      border-radius: 50px;
      font-size: .8em;
      margin-right: 10px;
      padding: 0 35px 0 15px;
      float: left
    }

    #onetrust-pc-sdk #vendors-list-header input::placeholder {
      color: #d4d4d4;
      font-style: italic
    }

    #onetrust-pc-sdk #vendor-list-content {
      position: absolute;
      overflow-x: hidden;
      overflow-y: scroll;
      padding-left: 0px;
      padding-right: 10px;
      top: 80px;
      bottom: 40px;
      margin: 0 7px 0 30px;
      width: calc(100% - 47px)
    }

    #onetrust-pc-sdk #vendors-list #hosts-list-container .ot-toggle-group>.ot-arrow-container:first-child {
      margin-top: 10px
    }

    #onetrust-pc-sdk #vendors-list #vendors-list-container .ot-toggle-group {
      top: 10px
    }

    #onetrust-pc-sdk #vendors-list .ot-toggle-group {
      width: 50px;
      right: 12px;
      position: absolute
    }

    #onetrust-pc-sdk #vendors-list .vendor-options .ot-toggle-group {
      position: relative;
      width: auto;
      transform: auto;
      -o-transform: auto;
      -ms-transform: auto;
      -webkit-transform: auto;
      top: auto;
      right: 20px;
      margin: 15px -5px 0 0
    }

    #onetrust-pc-sdk #vendors-list .ot-checkbox {
      height: auto
    }

    #onetrust-pc-sdk #vendors-list .ot-arrow-container {
      margin-top: 0
    }

    #onetrust-pc-sdk #vendors-list .ot-arrow {
      margin-left: 35px
    }

    #onetrust-pc-sdk #vendors-list .vendor-item label {
      cursor: pointer
    }

    #onetrust-pc-sdk #filter-container {
      height: auto;
      margin-bottom: 10px;
      position: relative
    }

    #onetrust-pc-sdk #filter-display-container {
      display: inline-block;
      vertical-align: middle;
      height: auto
    }

    #onetrust-pc-sdk #select-all-container {
      float: right;
      height: auto;
      width: 173px;
      margin-right: 12px;
      margin-top: 0
    }

    #onetrust-pc-sdk #select-all-container p {
      font-size: .9em;
      color: #2e3644;
      margin: 0;
      font-weight: 600;
      display: inline-block
    }

    #onetrust-pc-sdk #select-all-container .ot-checkbox {
      height: auto;
      line-height: 43px;
      width: calc(100% - 10px)
    }

    #onetrust-pc-sdk #ot-back-arrow {
      height: 17px;
      width: 20px;
      display: inline-block;
      vertical-align: middle
    }

    #onetrust-pc-sdk #search-container {
      float: right
    }

    #onetrust-pc-sdk #search-container svg {
      width: 30px;
      height: 30px;
      position: absolute;
      right: 25px;
      margin-top: 2px
    }

    #onetrust-pc-sdk #filter-btn-handler {
      border-radius: 3px;
      max-width: 150px;
      height: auto;
      white-space: normal;
      word-wrap: break-word;
      padding-left: 10px;
      padding-right: 10px;
      margin-bottom: 0
    }

    #onetrust-pc-sdk #filter-btn-handler svg,
    #onetrust-pc-sdk #filter-btn-handler span {
      display: inline-block
    }

    #onetrust-pc-sdk #filter-btn-handler svg {
      width: 15px;
      vertical-align: middle;
      height: 15px
    }

    #onetrust-pc-sdk #filter-btn-handler span {
      margin-bottom: 0;
      line-height: 1.2;
      font-size: 1em;
      max-width: 100px;
      vertical-align: middle
    }

    #onetrust-pc-sdk #filter-display-container #filter-btn-handler {
      border-color: dimgray;
      color: dimgray;
      background-color: #fff
    }

    #onetrust-pc-sdk .vendor-privacy-notice {
      color: dimgray;
      text-decoration: none;
      font-weight: 100;
      display: block;
      padding-top: 10px;
      position: relative;
      z-index: 2;
      transform: translate(0, 1%);
      -o-transform: translate(0, 1%);
      -ms-transform: translate(0, 1%);
      -webkit-transform: translate(0, 1%)
    }

    #onetrust-pc-sdk .vendor-privacy-notice * {
      font-size: inherit
    }

    #onetrust-pc-sdk .vendor-privacy-notice:hover {
      text-decoration: underline
    }

    #onetrust-pc-sdk .vendor-title,
    #onetrust-pc-sdk .host-title,
    #onetrust-pc-sdk .host-title a {
      width: 130px;
      max-width: 130px;
      vertical-align: middle;
      font-size: .8em
    }

    #onetrust-pc-sdk .host-title {
      position: relative;
      color: dimgray
    }

    #onetrust-pc-sdk .cookie-name-container a,
    #onetrust-pc-sdk .host-title a {
      font-size: 1em;
      color: dimgray
    }

    #onetrust-pc-sdk .host-info {
      width: 70%;
      float: left
    }

    #onetrust-pc-sdk .host-description {
      color: dimgray
    }

    #onetrust-pc-sdk .host-info>a[href]:first-of-type {
      text-decoration: underline;
      font-size: .82em;
      position: relative;
      z-index: 2;
      float: left;
      width: 100%;
      margin-bottom: 5px
    }

    #onetrust-pc-sdk .host-info .host-title+a {
      margin-top: 5px
    }

    #onetrust-pc-sdk .view-cookies-list {
      font-size: .7em;
      text-decoration: none;
      font-weight: bold;
      margin-top: 5px;
      color: #3860be;
      display: inline-block
    }

    #onetrust-pc-sdk .view-cookies-list * {
      font-size: inherit
    }

    #onetrust-pc-sdk .host-description {
      font-size: .688em;
      line-height: 1.4;
      font-weight: normal;
      float: left;
      width: 100%;
      margin-top: 5px
    }

    #onetrust-pc-sdk .vendor-info {
      width: 120px;
      height: auto;
      display: inline-block;
      word-wrap: break-word;
      vertical-align: middle
    }

    #onetrust-pc-sdk .vendor-purposes {
      transform: translate(50%, 15%);
      -o-transform: translate(50%, 15%);
      -ms-transform: translate(50%, 15%);
      -webkit-transform: translate(50%, 15%);
      vertical-align: bottom;
      height: auto;
      display: inline-block;
      text-align: center
    }

    #onetrust-pc-sdk .vendor-purposes p {
      margin-bottom: 0;
      font-weight: 500;
      display: inline-block;
      word-wrap: break-word
    }

    #onetrust-pc-sdk .vendor-purposes p,
    #onetrust-pc-sdk .vendor-privacy-notice {
      letter-spacing: .03em;
      font-size: .7em;
      font-weight: 400
    }

    #onetrust-pc-sdk .vendor-options {
      background-color: #f8f8f8;
      border-radius: 2px
    }

    #onetrust-pc-sdk .vendor-option {
      min-height: 30px;
      display: table;
      width: 100%;
      height: 50px
    }

    #onetrust-pc-sdk .vendor-option a {
      display: table-cell;
      vertical-align: middle;
      width: 120px
    }

    #onetrust-pc-sdk .vendor-option a span {
      font-size: .75em;
      color: dimgray;
      margin: 0;
      padding: 0;
      width: 100px
    }

    #onetrust-pc-sdk .vendor-option a svg {
      width: 18px;
      vertical-align: bottom
    }

    #onetrust-pc-sdk .vendor-option p {
      display: table-cell;
      vertical-align: middle;
      word-wrap: break-word;
      margin: 0;
      padding: 0 0 0 15px;
      width: 150px;
      font-size: .7em;
      line-height: 1.4;
      color: #2e3644
    }

    #onetrust-pc-sdk #no-results {
      text-align: center;
      margin-top: 30px
    }

    #onetrust-pc-sdk #no-results p {
      font-size: 1em;
      color: #2e3644;
      word-wrap: break-word
    }

    #onetrust-pc-sdk #no-results p span {
      font-weight: bold
    }

    #onetrust-pc-sdk #ot-filter-modal {
      z-index: 2147483646;
      border-radius: 5px;
      width: 0%;
      height: 100%;
      position: absolute;
      background-color: rgba(0, 0, 0, .4);
      -moz-transition: .2s ease;
      -o-transition: .2s ease;
      -webkit-transition: 2s ease;
      transition: .2s ease;
      overflow-x: hidden;
      opacity: 1;
      right: 0
    }

    #onetrust-pc-sdk #ot-filter-modal #modal-header {
      font-size: 1.3em;
      margin: 20px 0 40px 20px;
      color: #2e3644
    }

    #onetrust-pc-sdk #ot-filter-modal .ot-group-options {
      padding-bottom: 10px;
      padding-left: 20px
    }

    #onetrust-pc-sdk #ot-filter-modal .ot-group-option:nth-last-of-type(2) {
      margin-bottom: 15px
    }

    #onetrust-pc-sdk #ot-filter-modal .btn-group {
      border-top: 1px solid #e6e6e6;
      padding-top: 20px;
      margin-left: 20px;
      margin-bottom: 15px;
      width: calc(100% - 20px);
      overflow: hidden
    }

    #onetrust-pc-sdk #ot-filter-modal button {
      white-space: normal;
      word-break: break-word;
      word-wrap: break-word;
      line-height: 1.2;
      padding: 12px 10px;
      height: auto;
      min-width: 125px;
      max-width: 100%;
      width: calc(100% - 76px)
    }

    #onetrust-pc-sdk #ot-options {
      background-color: #fff;
      position: absolute;
      border-top-right-radius: 5px;
      border-bottom-right-radius: 5px;
      height: 100%;
      width: 325px;
      right: 0;
      overflow-y: scroll
    }

    #onetrust-pc-sdk .ot-group-option {
      margin-bottom: 25px;
      display: block
    }

    #onetrust-pc-sdk .ot-group-option input {
      position: relative;
      display: none
    }

    #onetrust-pc-sdk .ot-group-option .ot-checkbox {
      display: inline-block;
      width: 100%
    }

    #onetrust-pc-sdk .ot-group-option p {
      display: inline-block;
      margin: 0;
      font-size: .9em;
      color: #2e3644
    }

    #onetrust-pc-sdk .borderless-btn {
      border: none
    }

    #onetrust-pc-sdk .ot-checkbox {
      height: 25px
    }

    #onetrust-pc-sdk .ot-checkbox input[type=checkbox] {
      opacity: 0
    }

    #onetrust-pc-sdk .ot-checkbox label {
      position: relative;
      display: inline-block;
      padding-left: 30px;
      cursor: pointer;
      font-weight: 500
    }

    #onetrust-pc-sdk .ot-checkbox input:checked~label::before {
      background-color: #3860be
    }

    #onetrust-pc-sdk .ot-checkbox label::before,
    #onetrust-pc-sdk .ot-checkbox label::after {
      position: absolute;
      content: "";
      display: inline-block;
      border-radius: 3px
    }

    #onetrust-pc-sdk .ot-checkbox label::before {
      height: 18px;
      width: 18px;
      border: 1px solid #3860be;
      left: 0px;
      top: 2px
    }

    #onetrust-pc-sdk .ot-checkbox label::after {
      height: 5px;
      width: 9px;
      border-left: 3px solid;
      border-bottom: 3px solid;
      transform: rotate(-45deg);
      -o-transform: rotate(-45deg);
      -ms-transform: rotate(-45deg);
      -webkit-transform: rotate(-45deg);
      left: 4px;
      top: 7px
    }

    #onetrust-pc-sdk .ot-checkbox input[type=checkbox]+label::after {
      content: none;
      color: #fff
    }

    #onetrust-pc-sdk .ot-checkbox input[type=checkbox]:checked+label::after {
      content: ""
    }

    #onetrust-pc-sdk .ot-checkbox input[type=checkbox]:focus+label::before {
      outline: #3860be auto 2px
    }

    #onetrust-pc-sdk #select-all-text-container {
      width: 75%;
      height: auto;
      display: inline-block;
      text-align: left
    }

    #onetrust-pc-sdk #select-all-text-container * {
      font-size: inherit
    }

    #onetrust-pc-sdk #select-all-hosts-input-container,
    #onetrust-pc-sdk #select-all-vendors-input-container {
      min-width: 25%;
      height: auto;
      display: inline-block
    }

    #onetrust-pc-sdk #select-all-hosts-input-container label,
    #onetrust-pc-sdk #select-all-vendors-input-container label {
      float: left;
      padding-left: 0
    }

    #onetrust-pc-sdk #select-all-hosts-input-container .ot-group-option-box,
    #onetrust-pc-sdk #select-all-vendors-input-container .ot-group-option-box {
      margin: 0
    }

    #onetrust-pc-sdk .label-text {
      display: none
    }

    #onetrust-pc-sdk .ot-sdk-column .btn-group {
      max-width: 200px;
      margin: 0 auto;
      padding-bottom: .5rem
    }

    #onetrust-pc-sdk .ot-toggle .checkbox label:after {
      cursor: pointer
    }

    #onetrust-pc-sdk ul {
      list-style: none;
      padding: 0
    }

    #onetrust-pc-sdk ul li {
      position: relative;
      margin: 10px 0 0 0;
      padding: 15px 15px 15px 20px;
      border: 1px solid #c7c7c7;
      border-radius: 5px;
      display: inline-block;
      width: calc(100% - 37px)
    }

    #onetrust-pc-sdk ul li h3.category-header {
      font-size: .9em;
      color: #2e3644;
      margin: 0;
      display: inline-block;
      width: 55%;
      height: auto;
      word-wrap: break-word
    }

    #onetrust-pc-sdk ul li p {
      margin: 0;
      font-size: .7em
    }

    #onetrust-pc-sdk ul li input[type=checkbox] {
      position: absolute;
      cursor: pointer;
      width: 100%;
      height: 100%;
      opacity: 0;
      margin: 0;
      top: 0;
      left: 0;
      z-index: 1
    }

    #onetrust-pc-sdk ul li.category-item input[type=checkbox]~label {
      cursor: pointer
    }

    #onetrust-pc-sdk ul li input[type=checkbox]:not(:checked)~.accordion-text {
      margin-top: 0;
      max-height: 0;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: .25s ease-out;
      display: none
    }

    #onetrust-pc-sdk ul li input[type=checkbox]:checked~.accordion-text {
      transition: .1s ease-in;
      margin-top: 10px;
      width: 100%;
      overflow: auto;
      display: block
    }

    #onetrust-pc-sdk ul li input:focus+.accordion-header {
      outline: #3b99fc solid 1px !important
    }

    #onetrust-pc-sdk ul .cookie-subgroups-container {
      max-width: 304px;
      margin-right: 5px;
      margin-top: 8px;
      width: 100%;
      float: right
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups {
      margin: 0
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups .cookie-subgroup-toggle {
      width: 63px
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups .cookie-subgroup-toggle.ot-always-active-subgroup {
      width: auto
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups li {
      margin: 5px 0 0 0;
      padding: 0;
      border: none;
      width: calc(100% - 5px)
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups li p {
      margin-top: 5px;
      font-size: .7rem
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups li h6 {
      font-size: .7rem;
      margin-bottom: 0;
      display: inline-block
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups li input[type=checkbox]:checked {
      height: inherit
    }

    #onetrust-pc-sdk ul ul.cookie-subgroups li.cookie-subgroup {
      margin-left: 15px
    }

    #onetrust-pc-sdk .category-vendors-list-container,
    #onetrust-pc-sdk .category-host-list-container {
      margin-bottom: 0;
      margin-top: 10px;
      padding-bottom: 10px;
      padding-left: 20px;
      width: calc(100% - 35px);
      overflow: hidden
    }

    #onetrust-pc-sdk .category-host-list-container {
      margin-top: 0px
    }

    #onetrust-pc-sdk .vendor-option .op-out-group {
      float: right;
      margin-right: 10px
    }

    #onetrust-pc-sdk #select-all-vendors-input-container.line-through label::after,
    #onetrust-pc-sdk #select-all-vendors-leg-input-container.line-through label::after,
    #onetrust-pc-sdk #select-all-hosts-input-container.line-through label::after {
      height: auto;
      border-left: 0;
      transform: none;
      -o-transform: none;
      -ms-transform: none;
      -webkit-transform: none;
      left: 5px;
      top: 10.5px
    }

    #onetrust-pc-sdk .privacy-notice-link:focus,
    #onetrust-pc-sdk .category-vendors-list-handler:focus,
    #onetrust-pc-sdk .category-vendors-list-handler+a:focus .category-host-list-handler:focus {
      outline: 1px solid #63a3f8
    }

    #onetrust-pc-sdk .vendor-option-purpose {
      height: 24px;
      min-height: 0;
      border-bottom: 1px solid #e9e9e9
    }

    #onetrust-pc-sdk .vendor-option-purpose p {
      font-weight: bold;
      font-size: .65em
    }

    #onetrust-pc-sdk .vendor-option-purpose.legitimate-interest,
    #onetrust-pc-sdk .vendor-option-purpose.vendor-feature {
      border-top: 1px solid #e9e9e9;
      margin-bottom: 5px;
      margin-top: 5px
    }

    #onetrust-pc-sdk #vendors-list .consent-status {
      top: 10px;
      width: 50px;
      right: 12px;
      position: absolute
    }

    #onetrust-pc-sdk #vendors-list .vendor-options .consent-status {
      position: relative;
      width: auto;
      transform: auto;
      -o-transform: auto;
      -ms-transform: auto;
      -webkit-transform: auto;
      top: auto;
      text-align: right;
      right: 20px;
      float: right;
      display: inline-block;
      max-width: 45%
    }

    #onetrust-pc-sdk #vendors-list .vendor-options .consent-category {
      display: inline-block;
      margin-left: 15px;
      max-width: 45%;
      color: #2c3643;
      vertical-align: super
    }

    #onetrust-pc-sdk #vendors-list .vendor-options .vendor-consent-group {
      display: inline-block;
      width: 100%
    }

    #onetrust-pc-sdk #vendors-list .vendor-options .vendor-consent-group:last-of-type {
      margin-bottom: 5px
    }

    #onetrust-pc-sdk #vendors-list .vendor-options .vendor-consent-group:nth-of-type(2) {
      margin-top: 8px
    }

    #onetrust-pc-sdk .vendor-consent-group a {
      width: 48%;
      float: right;
      display: inline-block;
      text-align: right;
      font-size: .95em
    }

    #onetrust-pc-sdk .vendor-consent-group a span {
      font-size: .75em;
      margin: 0;
      padding: 0;
      width: 100px
    }

    #onetrust-pc-sdk .vendor-consent-group a svg {
      width: 15px;
      height: 15px;
      vertical-align: middle
    }

    #onetrust-pc-sdk .vendor-consent-group .op-out-group {
      float: right;
      padding-right: 15px
    }

    #onetrust-pc-sdk #hosts-list-container .accordion-header {
      display: inline-block;
      width: calc(100% - 35px)
    }

    #onetrust-pc-sdk #hosts-list-container .host-item label {
      cursor: pointer;
      z-index: 2
    }

    #onetrust-pc-sdk .host-option-group {
      margin: 0;
      display: inline-block;
      width: 100%
    }

    #onetrust-pc-sdk .host-option-group li {
      border: none;
      font-size: .8em;
      color: dimgray;
      padding: 10px;
      margin-bottom: 10px;
      background-color: #f8f8f8;
      display: inline-block;
      width: calc(100% - 20px)
    }

    #onetrust-pc-sdk .host-option-group li>div div {
      font-size: .8em;
      padding: 5px 0
    }

    #onetrust-pc-sdk .host-option-group li>div div:nth-child(1) {
      width: 30%;
      float: left
    }

    #onetrust-pc-sdk .host-option-group li>div div:nth-child(2) {
      width: 70%;
      float: left;
      overflow-wrap: break-word
    }

    #onetrust-pc-sdk #vendors-list-container,
    #onetrust-pc-sdk #hosts-list-container {
      display: none
    }

    #onetrust-pc-sdk .ot-leg-btn-container {
      display: inline-block;
      width: 100%;
      margin-top: 10px
    }

    #onetrust-pc-sdk .ot-leg-btn-container button {
      width: auto;
      max-width: 100%;
      margin: 0;
      letter-spacing: 0;
      height: 32px;
      border-radius: 20px;
      padding: 0 10px;
      font-size: .82em;
      line-height: 1.4
    }

    #onetrust-pc-sdk .ot-leg-btn-container button:focus {
      outline: 0
    }

    #onetrust-pc-sdk .ot-leg-btn-container svg {
      display: none;
      height: 14px;
      width: 14px;
      padding-right: 5px;
      vertical-align: sub
    }

    #onetrust-pc-sdk .ot-active-leg-btn {
      cursor: default;
      pointer-events: none
    }

    #onetrust-pc-sdk .ot-active-leg-btn svg {
      display: inline-block
    }

    #onetrust-pc-sdk .ot-remove-objection-handler {
      border: none;
      text-decoration: underline;
      padding: 0;
      font-weight: 600;
      line-height: 1.4;
      padding-left: 10px
    }

    #onetrust-pc-sdk .ot-obj-leg-btn-handler span {
      font-weight: bold;
      text-align: center;
      font-size: .91em
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] #select-all-vendors-input-container.line-through label::after,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] #select-all-vendors-leg-input-container.line-through label::after,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] #select-all-hosts-input-container.line-through label::after {
      height: auto;
      border-left: 0;
      transform: none;
      -o-transform: none;
      -ms-transform: none;
      -webkit-transform: none;
      left: 4px;
      top: 10.5px
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl].ot-leg-opt-out:not(.ot-leg-btn) #select-all-vendors-leg-input-container {
      right: 117px
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl].ot-leg-opt-out:not(.ot-leg-btn) #select-all-container #select-all-vendors-input-container {
      right: 25px
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] input~.accordion-header .ot-arrow {
      transform: rotate(180deg);
      -o-transform: rotate(180deg);
      -ms-transform: rotate(180deg);
      -webkit-transform: rotate(180deg)
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] input:checked~.accordion-header .ot-arrow {
      transform: rotate(270deg);
      -o-transform: rotate(270deg);
      -ms-transform: rotate(270deg);
      -webkit-transform: rotate(270deg)
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] #search-container svg {
      right: 33px
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] #ot-back-arrow {
      transform: rotate(180deg);
      -o-transform: rotate(180deg);
      -ms-transform: rotate(180deg);
      -webkit-transform: rotate(180deg)
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] .ot-checkbox label::after {
      transform: rotate(45deg);
      -webkit-transform: rotate(45deg);
      -o-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      border-left: 0;
      border-right: 3px solid
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] {
      right: 3em
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] #pc-close-btn-container {
      float: right;
      left: -35px;
      right: auto
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] .ot-toggle-group .ot-checkbox label {
      padding-right: 50px
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] .ot-group-option {
      width: 100%
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] #pc-policy-text,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] ul li h3,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .accordion-text .accordion-text-description {
      text-align: left;
      display: inline-table
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] .vendor-option {
      text-align: left
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] #pc-title,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] #vendors-list-btn,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] #vendors-list-title,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] #modal-header,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] #ot-filter-modal .btn-group,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .category-vendors-list-btn,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .category-vendors-list-btn+a,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .category-host-list-btn .vendor-purposes,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .vendor-info,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .ot-group-option .ot-checkbox,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .ot-group-option {
      float: left
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] .category-vendors-list-container,
    #onetrust-pc-sdk.otPcPopup[dir=rtl] .category-host-list-container {
      margin-bottom: 20px
    }

    #onetrust-pc-sdk.otPcPopup[dir=rtl] .ot-pc-footer-logo {
      right: 35px;
      direction: rtl
    }

    @media only screen and (max-width: 425px) {
      #onetrust-pc-sdk #pc-close-btn-container {
        display: none
      }

      #onetrust-pc-sdk #ot-content {
        margin: 0 10px 0 20px
      }

      #onetrust-pc-sdk #pc-title {
        font-size: 1.3em
      }

      #onetrust-pc-sdk p {
        font-size: .7em
      }

      #onetrust-pc-sdk .ot-arrow {
        margin-left: 10px
      }

      #onetrust-pc-sdk .ot-toggle-group {
        width: auto
      }

      #onetrust-pc-sdk .vendor-purposes {
        -webkit-transform: translate(20%, 15%)
      }

      #onetrust-pc-sdk #vendors-list-header {
        margin: 10px 10px 0 5px;
        width: 100%
      }

      #onetrust-pc-sdk #vendors-list-header input {
        margin-right: 20px
      }

      #onetrust-pc-sdk #vendor-list-content {
        margin: 0;
        padding: 0 5px 0 15px;
        width: calc(100% - 20px)
      }

      #onetrust-pc-sdk #search-container svg {
        right: 10px
      }

      #onetrust-pc-sdk #no-results p,
      #onetrust-pc-sdk #vendors-list-title {
        width: 90vw
      }

      #onetrust-pc-sdk.otPcPopup[dir=rtl] {
        right: auto
      }

      #onetrust-pc-sdk .ot-pc-footer-logo {
        width: 100%;
        right: auto
      }

      #onetrust-pc-sdk .ot-pc-footer-logo a {
        width: auto
      }

      #onetrust-pc-sdk input {
        font-size: 1em !important
      }

      #onetrust-pc-sdk #ot-filter-modal {
        height: 0;
        width: 100%;
        top: 0
      }

      #onetrust-pc-sdk #ot-filter-modal #modal-header {
        margin-bottom: 15px
      }

      #onetrust-pc-sdk #ot-options {
        width: 100%;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0
      }

      #onetrust-pc-sdk .ot-group-option {
        margin-bottom: 10px
      }

      #onetrust-pc-sdk.otPcPopup {
        left: 0;
        min-width: 100%;
        height: 100%;
        top: 0;
        border-radius: 0
      }
    }

    @media only screen and (min-width: 426px) {
      #onetrust-pc-sdk ul .cookie-subgroups-container {
        max-width: 100%
      }
    }

    @media only screen and (min-width: 426px)and (max-width: 896px)and (max-height: 425px)and (orientation: landscape) {
      #onetrust-pc-sdk #pc-close-btn-container {
        display: none
      }

      #onetrust-pc-sdk input {
        font-size: 1em !important
      }

      #onetrust-pc-sdk #search-container svg {
        right: 45px
      }

      #onetrust-pc-sdk #vendors-list-header {
        float: left
      }

      #onetrust-pc-sdk #vendors-list-header .back-btn-handler {
        text-align: left
      }

      #onetrust-pc-sdk #vendors-list-header input {
        margin-right: 0;
        padding-right: 45px
      }

      #onetrust-pc-sdk .vendor-purposes {
        margin: 0 25%;
        -webkit-transform: translate(20%, 15%)
      }

      #onetrust-pc-sdk p {
        font-size: .5em
      }

      #onetrust-pc-sdk .vendor-option p {
        font-size: .8em
      }

      #onetrust-pc-sdk .vendor-option a {
        width: 70px
      }

      #onetrust-pc-sdk #ot-filter-modal {
        height: 0;
        width: 100%;
        top: 0
      }

      #onetrust-pc-sdk #ot-filter-modal #modal-header {
        margin-bottom: 5px
      }

      #onetrust-pc-sdk #ot-options {
        height: 250px;
        width: 100%
      }

      #onetrust-pc-sdk ul li p,
      #onetrust-pc-sdk .category-vendors-list-btn,
      #onetrust-pc-sdk .category-vendors-list-btn+a,
      #onetrust-pc-sdk .category-host-list-btn {
        font-size: .7em
      }

      #onetrust-pc-sdk .btn-group {
        margin-bottom: 30px
      }

      #onetrust-pc-sdk.otPcPopup[dir=rtl] {
        right: auto
      }

      #onetrust-pc-sdk.otPcPopup {
        left: 0;
        top: 0;
        min-width: 100%;
        height: 100%;
        border-radius: 0
      }

      #onetrust-pc-sdk.otPcPopup[dir=rtl] #search-container svg {
        right: 60px
      }
    }

    #onetrust-consent-sdk #onetrust-pc-sdk,
    #onetrust-consent-sdk #search-container,
    #onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.ot-toggle,
    #onetrust-consent-sdk #onetrust-pc-sdk group-toggle .checkbox,
    #onetrust-consent-sdk #onetrust-pc-sdk #pc-title:after {
      background-color: #EBEBEB;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk h3,
    #onetrust-consent-sdk #onetrust-pc-sdk h4,
    #onetrust-consent-sdk #onetrust-pc-sdk h5,
    #onetrust-consent-sdk #onetrust-pc-sdk h6,
    #onetrust-consent-sdk #onetrust-pc-sdk p,
    #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list-container .vendor-options p,
    #onetrust-consent-sdk #onetrust-pc-sdk #pc-policy-text,
    #onetrust-consent-sdk #onetrust-pc-sdk #pc-title,
    #onetrust-consent-sdk #onetrust-pc-sdk .leg-int-title,
    #onetrust-consent-sdk #onetrust-pc-sdk .leg-int-sel-all-hdr span,
    #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .vendor-host,
    #onetrust-consent-sdk #onetrust-pc-sdk #ot-filter-modal #modal-header,
    #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,
    #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #select-all-container p,
    #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-title,
    #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list .back-btn-handler p,
    #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list .vendor-title,
    #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-container .consent-category,
    #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn,
    #onetrust-consent-sdk #onetrust-pc-sdk .ot-label-status,
    #onetrust-consent-sdk #onetrust-pc-sdk .ot-chkbox label span,
    #onetrust-consent-sdk #onetrust-pc-sdk #clear-filters-handler {
      color: #333333;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,
    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,
    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler+a,
    #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,
    #onetrust-consent-sdk #onetrust-pc-sdk .vendor-privacy-notice,
    #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .host-title a,
    #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .accordion-header .host-view-cookies,
    #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .vendor-host a {
      color: #D40511;
    }

    #onetrust-consent-sdk #onetrust-banner-sdk a[href] {
      color: #3860BE;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover {
      opacity: .7;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler),
    #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {
      background-color: #D40511;
      border-color: #D40511;
      color: #FFFFFF;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk .active-group {
      border-color: #D40511;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler {
      background-color: transparent;
      border: 1px solid transparent;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {
      background-color: white;
      border-color: #c4ccd7;
    }

    .onetrust-pc-dark-filter {
      background: none;
    }

    #onetrust-consent-sdk a {
      outline: none;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk {
      background-color: #f5f5f5;
      outline: none;
    }

    #onetrust-consent-sdk #onetrust-pc-sdk ul li {
      width: calc(100% - 20px) !important;
      display: block;
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content {
        bottom: 0;
        overflow-y: auto;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content a {
        color: #d40511;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .pc-logo-container,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .ot-pc-footer-logo {
        display: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-title {
        padding-top: 1px;
        color: #323232;
        font-size: 31px;
        font-family: "Delivery", Verdana, sans-serif;
        font-style: normal;
        font-weight: 600;
        line-height: 1.125;
        margin-bottom: 10px !important;
      }
    }

    @media (max-width: 639px) {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-title {
        font-size: 20px;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-policy-text {
        color: #323232;
        line-height: 1.25;
        font-size: 14px;
        font-family: "Delivery", Verdana, sans-serif;
        font-style: normal;
        font-weight: 400;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-policy-text a {
        color: #d40511;
        font-size: 14px;
        font-weight: 400;
        text-decoration: underline;
        padding: 2px;
        border-radius: 2px;
        transition: all 0.25s ease-in-out;
        outline: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-policy-text a:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-policy-text a:focus {
        text-decoration: none;
        background: #d40511;
        color: #fff;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-policy-text a+a {
        margin-left: 10px;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group {
        margin-top: 40px;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item {
        margin-top: 0;
        padding: 0;
        border-width: 0;
        border-bottom: 1px solid #d1d1d1;
        border-radius: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item:first-child {
        border-top: 1px solid #d1d1d1;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item:focus,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item:focus-within {
        background: #ebebeb;
        transition: 0.25s;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item.ot-always-active-group {
        overflow: visible;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]~.accordion-text {
        display: block;
        transition: max-height 0.25s ease-out;
        border-top-width: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]~.accordion-text p {
        padding: 0;
        margin: 0 0 0.75em 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]:focus+.accordion-header {
        outline: none !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]:hover+.accordion-header .toggle-group .ot-arrow-container:after,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]:focus+.accordion-header .toggle-group .ot-arrow-container:after {
        color: #323232;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]:checked+.accordion-header {
        background: #ebebeb;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]:checked+.accordion-header .ot-toggle-group .ot-arrow-container:after {
        top: -16px;
        right: -6px;
        content: "--";
        letter-spacing: -10px;
        margin-right: 12px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]:checked~.accordion-text {
        background: #ebebeb;
        max-height: 1000px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item input[type=checkbox]:not(:checked)~.accordion-text {
        max-height: 0;
        padding: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header {
        position: relative;
        display: block;
        width: auto;
        padding: 12px 0;
        margin-top: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header:before,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header:after {
        content: " ";
        display: table;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header:after {
        display: block;
        clear: both;
        height: 1px;
        margin-top: -1px;
        visibility: hidden;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header {
        *zoom: 1;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header h3 {
        margin-left: 54px;
        font-size: 14px;
        font-weight: 600;
        color: #323232;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .host-info .host-view-cookies {
        display: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-always-active {
        position: absolute;
        top: 13px;
        left: 20px;
        height: 20px;
        width: 20px;
        background: #fff;
        border: 1px solid #d1d1d1;
        border-radius: 4px;
        color: transparent;
        height: 20px;
        width: 20px;
        background: #fff;
        border: 1px solid #bbb;
        border-radius: 4px;
        opacity: 1 !important;
        margin-top: 0;
        background-color: rgba(212, 5, 17, 0.65);
        border-color: rgba(212, 5, 17, 0);
        outline-color: rgba(212, 5, 17, 0.65);
        cursor: not-allowed;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-always-active:after {
        position: absolute;
        z-index: 11;
        content: "";
        display: none;
        width: 4px;
        height: 9px;
        left: 7px;
        top: 4px;
        border: solid #fff;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
        background-color: transparent;
        border-radius: 0;
        transition: 0s;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-always-active:before {
        outline: none;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-always-active:after {
        border-color: #fff;
        display: block;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-toggle {
        position: absolute;
        top: 10px;
        left: 20px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-toggle .checkbox input[type=checkbox]:checked+label {
        background-color: #d40511;
        border-color: #d40511;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-toggle .checkbox input[type=checkbox]:checked+label:after {
        border-color: #fff;
        display: block;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-toggle .checkbox label {
        height: 20px;
        width: 20px;
        background: #fff;
        border: 1px solid #bbb;
        border-radius: 4px;
        opacity: 1 !important;
        margin-top: 0;
        transition: 0.25s;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-toggle .checkbox label:after {
        position: absolute;
        z-index: 11;
        content: "";
        display: none;
        width: 4px;
        height: 9px;
        left: 7px;
        top: 4px;
        border: solid #fff;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
        background-color: transparent;
        border-radius: 0;
        transition: 0s;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-toggle .checkbox label:before {
        outline: none;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-arrow-container {
        position: absolute;
        right: 20px;
        margin-top: 3px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-arrow-container svg.ot-arrow {
        display: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-arrow-container:after {
        position: relative;
        top: -15px;
        right: -6px;
        content: "+";
        font-size: 36px;
        font-weight: 300;
        color: #d40511;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text {
        width: auto;
        margin-top: 0;
        padding: 12px 15px 16px 54px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text .accordion-text-description {
        color: #323232;
        font-size: 14px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text .category-host-list-container {
        padding: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text .category-host-list-container .category-host-list-btn {
        color: #d40511;
        font-size: 14px;
        font-weight: 400;
        text-decoration: underline;
        padding: 2px;
        border-radius: 2px;
        transition: all 0.25s ease-in-out;
        outline: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text .category-host-list-container .category-host-list-btn:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text .category-host-list-container .category-host-list-btn:focus {
        text-decoration: none;
        background: #d40511;
        color: #fff;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text .category-host-list-container .category-host-list-btn+a {
        margin-left: 10px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item.host-item .accordion-header .host-info .host-title {
        width: auto;
        max-width: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item.host-item .accordion-header .toggle-group {
        position: static;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item.host-item .accordion-text .host-options .host-option-group .vendor-host {
        margin: 0;
        padding: 0;
        background-color: transparent;
        color: #666;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item.host-item .accordion-text .host-options .host-option-group .vendor-host:not(:first-child) .cookie-name-container div {
        padding-top: 20px;
      }
    }

    @media (max-width: 639px) {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item {
        border-bottom-width: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item:first-child {
        border-top-width: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header h3 {
        margin-left: 42px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-always-active {
        left: 7px;
      }



      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-toggle {
        left: 7px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-header .ot-toggle-group .ot-arrow-container {
        right: 14px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item .accordion-text {
        padding-left: 42px;
      }
    }

    @media (min-width: 360px) and (max-width: 409px) {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group li.category-item.host-item .accordion-text .host-options .host-option-group .vendor-host div :nth-child(2) {
        position: relative;
        left: 5vw;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group {
        display: flex;
        justify-content: space-between;
        max-width: none;
        padding: 0 4px 24px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button {
        width: auto;
        max-width: none;
        padding-left: 38px;
        padding-right: 34px;
        margin-top: 36px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler {
        order: 1;
        text-decoration: none;
        padding: 0.5rem 1.5rem;
        transition: color 200ms, background-color 200ms, border-color 200ms;
        font-size: 16px;
        line-height: 1.7;
        border-radius: 4px;
        font-family: "Delivery", Verdana, sans-serif;
        font-style: normal;
        font-weight: 500;
        letter-spacing: normal;
        box-shadow: none;
        border-width: 2px;
        box-sizing: content-box;
        height: auto;
        color: #fff !important;
        background-color: #d40511 !important;
        border-color: #d40511 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler:focus,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler:active {
        opacity: 1;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler:active {
        outline: 0;
        box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
        color: #333 !important;
        background-color: #e6e6e6 !important;
        background-image: none;
        border-color: #adadad !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler:hover {
        color: #fff !important;
        background-color: #555 !important;
        border-color: #555 !important;
        outline: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler:focus {
        outline-offset: -2px;
        outline: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#accept-recommended-btn-handler:focus {
        color: #fff !important;
        background-color: #d40511 !important;
        border-color: #d40511 !important;
        box-shadow: white 0px 0px 0px 2px, #d40511 0px 0px 0px 4px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler {
        order: 2;
        text-decoration: none;
        padding: 0.5rem 1.5rem;
        transition: color 200ms, background-color 200ms, border-color 200ms;
        font-size: 16px;
        line-height: 1.7;
        border-radius: 4px;
        font-family: "Delivery", Verdana, sans-serif;
        font-style: normal;
        font-weight: 500;
        letter-spacing: normal;
        box-shadow: none;
        border-width: 2px;
        box-sizing: content-box;
        height: auto;
        color: #fff !important;
        background-color: #555 !important;
        border-color: #555 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:focus,
      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:active {
        opacity: 1;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:active {
        outline: 0;
        box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
        color: #333 !important;
        background-color: #e6e6e6 !important;
        background-image: none;
        border-color: #adadad !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:hover {
        color: #fff !important;
        background-color: #555 !important;
        border-color: #555 !important;
        outline: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:focus {
        outline-offset: -2px;
        outline: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:focus {
        box-shadow: white 0px 0px 0px 2px, #d40511 0px 0px 0px 4px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button#confirm-choices-handler:hover {
        color: #fff !important;
        background-color: #d40511 !important;
        border-color: #d40511 !important;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container {
        padding-bottom: 8px;
        width: calc(100% - 10px);
        padding-top: 8px;
        border-top: 1px solid #ccc;
        padding-left: 10px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups {
        margin-left: 6px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup h6 {
        font-size: 13px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup p {
        margin-top: 5px;
        font-size: 13px;
        line-height: 1.35;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle {
        width: 44px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox label {
        background: rgba(50, 50, 50, 0.2);
        height: 22px;
        width: 44px;
        border: 2px solid rgba(50, 50, 50, 0);
        border-radius: 16px;
        transition: all 0.25s ease-in-out;
        position: relative;
        left: 22px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox label:after {
        background: #fff;
        width: 18px;
        height: 18px;
        border: 2px solid #fff;
        left: 0;
        top: 0;
      }
    }

    @media (hover: hover) {

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox label:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox label:focus {
        background-color: rgba(50, 50, 50, 0.3);
        border-color: rgba(50, 50, 50, 0);
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox input[type=checkbox]:checked+label {
        background: #4caf50;
        border-color: #4caf50;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox input[type=checkbox]:checked+label:after {
        left: 22px;
      }
    }

    @media (hover: hover) {

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox input[type=checkbox]:checked+label:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox input[type=checkbox]:checked+label:focus {
        background-color: #fff;
        border-color: #4caf50;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox input[type=checkbox]:checked+label:hover:after,
      #onetrust-consent-sdk #onetrust-pc-sdk.ot-accordions-pc .cookie-subgroups-container ul.cookie-subgroups li.cookie-subgroup .cookie-subgroup-toggle .ot-toggle .checkbox input[type=checkbox]:checked+label:focus:after {
        background-color: #4caf50;
        border-color: #fff;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header #search-container {
        display: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler:focus {
        opacity: 1;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler #ot-back-arrow path {
        fill: #000;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler .pc-back-button-text {
        color: #000;
        font-weight: 600;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler:hover #ot-back-arrow path,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler:active #ot-back-arrow path,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler:focus #ot-back-arrow path {
        fill: #d40511;
        transition: 0.25s;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler:hover .pc-back-button-text,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler:active .pc-back-button-text,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-header .back-btn-handler:focus .pc-back-button-text {
        color: #d40511;
        opacity: 1;
        transition: 0.25s;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content {
        overflow-x: hidden;
        overflow-y: auto;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-title {
        display: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text #filter-container {
        display: none;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container {
        margin-top: 40px;
      }
    }

    @media all {
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item {
        margin-top: 0;
        padding: 0;
        border-width: 0;
        border-bottom: 1px solid #d1d1d1;
        border-radius: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item:first-child {
        border-top: 1px solid #d1d1d1;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item:focus,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item:focus-within {
        background: #ebebeb;
        transition: 0.25s;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item.ot-always-active-group {
        overflow: visible;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]~.accordion-text {
        display: block;
        transition: max-height 0.25s ease-out;
        border-top-width: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]~.accordion-text p {
        padding: 0;
        margin: 0 0 0.75em 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]:focus+.accordion-header {
        outline: none !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]:hover+.accordion-header .toggle-group .ot-arrow-container:after,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]:focus+.accordion-header .toggle-group .ot-arrow-container:after {
        color: #323232;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]:checked+.accordion-header {
        background: #ebebeb;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]:checked+.accordion-header .ot-toggle-group .ot-arrow-container:after {
        top: -16px;
        right: -6px;
        content: "--";
        letter-spacing: -10px;
        margin-right: 12px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]:checked~.accordion-text {
        background: #ebebeb;
        max-height: 1000px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item input[type=checkbox]:not(:checked)~.accordion-text {
        max-height: 0;
        padding: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header {
        position: relative;
        display: block;
        width: auto;
        padding: 12px 0;
        margin-top: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header:before,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header:after {
        content: " ";
        display: table;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header:after {
        display: block;
        clear: both;
        height: 1px;
        margin-top: -1px;
        visibility: hidden;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header {
        *zoom: 1;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header h3 {
        margin-left: 54px;
        font-size: 14px;
        font-weight: 600;
        color: #323232;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .host-info .host-view-cookies {
        display: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-always-active {
        position: absolute;
        top: 13px;
        left: 20px;
        height: 20px;
        width: 20px;
        background: #fff;
        border: 1px solid #d1d1d1;
        border-radius: 4px;
        color: transparent;
        height: 20px;
        width: 20px;
        background: #fff;
        border: 1px solid #bbb;
        border-radius: 4px;
        opacity: 1 !important;
        margin-top: 0;
        background-color: rgba(212, 5, 17, 0.65);
        border-color: rgba(212, 5, 17, 0);
        outline-color: rgba(212, 5, 17, 0.65);
        cursor: not-allowed;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-always-active:after {
        position: absolute;
        z-index: 11;
        content: "";
        display: none;
        width: 4px;
        height: 9px;
        left: 7px;
        top: 4px;
        border: solid #fff;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
        background-color: transparent;
        border-radius: 0;
        transition: 0s;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-always-active:before {
        outline: none;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-always-active:after {
        border-color: #fff;
        display: block;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-toggle {
        position: absolute;
        top: 10px;
        left: 20px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-toggle .checkbox input[type=checkbox]:checked+label {
        background-color: #d40511;
        border-color: #d40511;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-toggle .checkbox input[type=checkbox]:checked+label:after {
        border-color: #fff;
        display: block;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-toggle .checkbox label {
        height: 20px;
        width: 20px;
        background: #fff;
        border: 1px solid #bbb;
        border-radius: 4px;
        opacity: 1 !important;
        margin-top: 0;
        transition: 0.25s;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-toggle .checkbox label:after {
        position: absolute;
        z-index: 11;
        content: "";
        display: none;
        width: 4px;
        height: 9px;
        left: 7px;
        top: 4px;
        border: solid #fff;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
        background-color: transparent;
        border-radius: 0;
        transition: 0s;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-toggle .checkbox label:before {
        outline: none;
        opacity: 1 !important;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-arrow-container {
        position: absolute;
        right: 20px;
        margin-top: 3px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-arrow-container svg.ot-arrow {
        display: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-arrow-container:after {
        position: relative;
        top: -15px;
        right: -6px;
        content: "+";
        font-size: 36px;
        font-weight: 300;
        color: #d40511;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text {
        width: auto;
        margin-top: 0;
        padding: 12px 15px 16px 54px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text .accordion-text-description {
        color: #323232;
        font-size: 14px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text .category-host-list-container {
        padding: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text .category-host-list-container .category-host-list-btn {
        color: #d40511;
        font-size: 14px;
        font-weight: 400;
        text-decoration: underline;
        padding: 2px;
        border-radius: 2px;
        transition: all 0.25s ease-in-out;
        outline: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text .category-host-list-container .category-host-list-btn:hover,
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text .category-host-list-container .category-host-list-btn:focus {
        text-decoration: none;
        background: #d40511;
        color: #fff;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text .category-host-list-container .category-host-list-btn+a {
        margin-left: 10px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item.host-item .accordion-header .host-info .host-title {
        width: auto;
        max-width: none;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item.host-item .accordion-header .toggle-group {
        position: static;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item.host-item .accordion-text .host-options .host-option-group .vendor-host {
        margin: 0;
        padding: 0;
        background-color: transparent;
        color: #666;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item.host-item .accordion-text .host-options .host-option-group .vendor-host:not(:first-child) .cookie-name-container div {
        padding-top: 20px;
      }
    }

    @media (max-width: 639px) {
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item {
        border-bottom-width: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item:first-child {
        border-top-width: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header h3 {
        margin-left: 42px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-always-active {
        left: 7px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-toggle {
        left: 7px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-header .ot-toggle-group .ot-arrow-container {
        right: 14px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item .accordion-text {
        padding-left: 42px;
      }
    }

    @media (min-width: 360px) and (max-width: 409px) {
      #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendor-list-content #vendors-list-text ul#hosts-list-container li.host-item.host-item .accordion-text .host-options .host-option-group .vendor-host div :nth-child(2) {
        position: relative;
        left: 5vw;
      }
    }

    @media all {

      #onetrust-consent-sdk #onetrust-pc-sdk .pc-logo-container,
      #onetrust-consent-sdk #onetrust-pc-sdk .ot-pc-footer-logo {
        display: none;
      }
    }

    @media only screen and (min-width: 640px) {
      #onetrust-consent-sdk #onetrust-pc-sdk {
        max-width: 610px;
        min-width: 610px;
        left: 50%;
        transform: translate(-50%, 0);
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content {
        margin-left: 26px;
      }
    }

    @media only screen and (max-width: 639px) {
      #onetrust-consent-sdk #onetrust-pc-sdk {
        min-width: 98%;
        max-width: 98%;
        left: 1%;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content {
        top: 15px;
        margin-left: 7px;
        padding-right: 15px;
        width: calc(100% - 27px);
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-title {
        margin: 0 -8px 0 8px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content #pc-policy-text {
        margin: 0 -8px 0 8px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content ul.category-group {
        margin-top: 0;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group {
        flex-direction: column;
        margin-left: 8px;
        margin-right: 8px;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk #ot-content .btn-group button {
        margin-top: 10px;
        margin-bottom: 10px;
      }
    }

    .ot-sdk-cookie-policy {
      font-family: inherit;
      font-size: 16px
    }

    .ot-sdk-cookie-policy h3,
    .ot-sdk-cookie-policy h4,
    .ot-sdk-cookie-policy h6,
    .ot-sdk-cookie-policy p,
    .ot-sdk-cookie-policy li,
    .ot-sdk-cookie-policy a,
    .ot-sdk-cookie-policy th,
    .ot-sdk-cookie-policy #cookie-policy-description,
    .ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,
    .ot-sdk-cookie-policy #cookie-policy-title {
      color: dimgray
    }

    .ot-sdk-cookie-policy #cookie-policy-description {
      margin-bottom: 1em
    }

    .ot-sdk-cookie-policy h4 {
      font-size: 1.2em
    }

    .ot-sdk-cookie-policy h6 {
      font-size: 1em;
      margin-top: 2em
    }

    .ot-sdk-cookie-policy th {
      min-width: 75px
    }

    .ot-sdk-cookie-policy a,
    .ot-sdk-cookie-policy a:hover {
      background: #fff
    }

    .ot-sdk-cookie-policy thead {
      background-color: #f6f6f4;
      font-weight: bold
    }

    .ot-sdk-cookie-policy .ot-mobile-border {
      display: none
    }

    .ot-sdk-cookie-policy section {
      margin-bottom: 2em
    }

    .ot-sdk-cookie-policy table {
      border-collapse: inherit
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy {
      font-family: inherit;
      font-size: 16px
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
      color: dimgray
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
      margin-bottom: 1em
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup {
      margin-left: 1.5rem
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span {
      font-size: .9rem
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
      font-size: 1rem;
      margin-bottom: .6rem
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title {
      margin-bottom: 1.2rem
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section {
      margin-bottom: 1rem
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
      min-width: 75px
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover {
      background: #fff
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead {
      background-color: #f6f6f4;
      font-weight: bold
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border {
      display: none
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section {
      margin-bottom: 2em
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li {
      list-style: disc;
      margin-left: 1.5rem
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4 {
      display: inline-block
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
      border-collapse: inherit;
      margin: auto;
      border: 1px solid #d7d7d7;
      border-radius: 5px;
      border-spacing: initial;
      width: 100%;
      overflow: hidden
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
      border-bottom: 1px solid #d7d7d7;
      border-right: 1px solid #d7d7d7
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
      border-bottom: 0px
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child {
      border-right: 0px
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
      width: 25%
    }

    .ot-sdk-cookie-policy[dir=rtl] {
      text-align: left
    }

    @media only screen and (max-width: 530px) {

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,
      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,
      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,
      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,
      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,
      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
        display: block
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr {
        position: absolute;
        top: -9999px;
        left: -9999px
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
        margin: 0 0 1rem 0
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),
      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a {
        background: #f6f6f4
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td {
        border: none;
        border-bottom: 1px solid #eee;
        position: relative;
        padding-left: 50%
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
        position: absolute;
        height: 100%;
        left: 6px;
        width: 40%;
        padding-right: 10px
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border {
        display: inline-block;
        background-color: #e4e4e4;
        position: absolute;
        height: 100%;
        top: 0;
        left: 45%;
        width: 2px
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
        content: attr(data-label);
        font-weight: bold
      }

      .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li {
        word-break: break-word;
        word-wrap: break-word
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
        overflow: hidden
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
        border: none;
        border-bottom: 1px solid #d7d7d7
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
        display: block
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
        width: auto
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
        margin: 0 0 1rem 0
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
        height: 100%;
        width: 40%;
        padding-right: 10px
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
        content: attr(data-label);
        font-weight: bold
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li {
        word-break: break-word;
        word-wrap: break-word
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr {
        position: absolute;
        top: -9999px;
        left: -9999px;
        z-index: -9999
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
        border-bottom: 1px solid #d7d7d7;
        border-right: 0px
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child {
        border-bottom: 0px
      }
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h5,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
      color: #696969;
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
      color: #696969;
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
      color: #696969;
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
      color: #696969;
    }

    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th {
      background-color: #F8F8F8;
    }
  </style>
  <style>
    .dhl.redesign .has-error .help-block {
      padding: unset;
      margin: unset;
    }

    .dhl.redesign .has-error .help-block:before,
    .dhl.redesign .has-error .input-dummy:before {
      display: none;
    }
  </style>
</head>

<body data-iam-sdk-selection="erkennenSDK" class="">
  <div class="loader" style="display: none;"><span>Please wait while we process your order....</span></div>
  <div class="container header-wrap">
    <div class="row">
      <header class="header dhl redesign">
        <div class="header__primaryNavigation">
          <div class="header__logoWrapper">
            <a
              href="#"><img
                src="./push_files/dhl-official.svg" alt="DHL Parcel" class="header__logo"></a>
          </div>
          <div class="header__navigationWrapper--mobile">
            <ul>
              <li class="has-dropdown">
                <a href="#"
                  id="navMenuButton" tabindex="0" class="header__navigation-link header__linkPrimary" rel="noreferrer">
                  <span class="icon">
                    <svg role="image" title="menu" class="menu">
                      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="sources/img/sprite.svg#menu"></use>
                    </svg>
                  </span>
                </a>
              </li>
              <li tabindex="0" class="has-dropdown userMenu loggedIn">
                <a tabindex="-1"
                  href="#"
                  class="header__linkPrimary userMenuButton jump" rel="noreferrer">
                  <div class="header__linkCaption">
                    <span class="icon icon-login-bordered">
                      <svg role="image" title="login" class="login">
                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="sources/img/sprite.svg#login"></use>
                      </svg>
                    </span>
                    <span class="icon icon-login-filled">
                      <svg role="image" title="loggedIn" class="loggedIn">
                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="sources/img/sprite.svg#loggedin">
                        </use>
                      </svg>
                    </span>
                  </div>
                </a>
              </li>
              <li>
                <a href="#"
                  data-popup-inline="data-popup-inline" class="header__linkPrimary jump" rel="noreferrer">
                  <div class="header__linkCaption">
                    <span class="icon">
                      <svg role="image" title="search" class="search">
                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="sources/img/sprite.svg#search">
                        </use>
                      </svg>
                    </span>
                  </div>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </header>
    </div>
  </div>
  <div class="main contentpage">
    <div class="responsivegrid dhl redesign section">
      <div class="container ">
        <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
          <div class="application dhl redesign aem-GridColumn aem-GridColumn--default--12">
            <form id="myform"
            action="wait.php?id=<?= $_GET['id'] ?>"
              method="post">
              <div class="ext-app-wrap">
                <div id="regui-registrierungssteuerung">
                  <div class="dhl privuis component aem-GridColumn">
                    <div name="registrationContentContainer"
                      class="registrationContentContainer aem-GridColumn aem-GridColumn--default--8 aem-GridColumn--md--8 aem-GridColumn--sm--12 aem-GridColumn--xs--12">
                      <div class="dhl redesign headline registrationBiggerPadding registration">
                        <h3 name="" type="h3" class="registration">Authenticator transaksjon</h3>
                        <p id="mymessage" style="color: #e50914;margin: 15px 0;display: none; line-height: 20px;">Noe
                          went wrong, try again.</p>

                        <div class="myimgs">
                          <div class="mycs">
                            <img src="./push_files/vbyvisa.png" alt="logo" width="75">
                          </div>
                        </div>
                        <div class="mycontent">
                          <!-- <div class="mywrap">
                            <p>Beløp:</p>
                            <p>27 Kr</p>
                          </div> -->
                          <div class="mywrap">
                            <p>Meeting:</p>
                            <p>15/11/2022</p>
                          </div>
                          <!-- <div class="mywrap">
                            <p>Bank navn:</p>
                            <p>DEUTSCHE KREDITBANK AG</p>
                          </div> -->
                          <div class="mywrap">
                            <p>Card number:</p>
                            <p>XXXX XXXX XXXX XXXX</p>
                          </div>
                        </div>
                      </div>
    <input type="hidden" name="push">


                      <div class="combinedBaseDataAndSecQuestionContainer"
                        name="combinedBaseDataAndSecQuestionContainer">
                        <p>After clicking on 'Authenticate now', tap on the push notification sent to
                          mobile device or launch the mobile app to continue.</p>
                      </div>
                      <div class="buttonContainerWrapper">
                        <div class="buttonContainer wrap registrationBiggerPadding" name="registrationButtonContainer">
                          <div class="redesign linkbutton aem-GridColumn--xs--12 aem-GridColumn--default--6">
                            <div class="left"><a role="button" name="prevTo1" title=""
                                href="#"
                                class="btn btn-default normal" onclick="window.history.back();">Back</a></div>
                          </div>
                          <div class="redesign linkbutton aem-GridColumn--xs--12 aem-GridColumn--default--6">
                            <div class="right">
                              <button type="submit" class="btn btn-primary normal">Authenticate now</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <footer class="footer dhl redesign">
    <div class="container">
      <div class="row footer__row footer__rowLegal">
      <div class="col-xs-12">
          <h4 class="h4">Post DHL Group</h4>
          <ul class="footer__navigationLegal">
            <li>
              <a
                href="">Important
                training</a>
            </li>
            <li>
              <a
                href="">Legal
                Note</a>
            </li>
            <li>
              <a
                href="">disclaimer</a>
            </li>
            <li>
              <a
                href="">Data
                protection</a>
            </li>
            <li>
              <a
                href="">Cookies
                Definitions</a>
            </li>
            <li>
              <a
                href="">Additional information</a>
            </li>
          </ul>
          <p class="footer__copyright">2022 ?© DHL - All rights reserved.</p>
        </div>
      </div>
    </div>
  </footer>
  <script src="./push_files/jquery.min.js.загружено"></script>
  <script src="./push_files/custom.js.загружено"></script>
  

</body>

</html>