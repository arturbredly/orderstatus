<?php


header("Location: www.dhl.com");